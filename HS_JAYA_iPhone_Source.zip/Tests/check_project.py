"""Structural checks only; this does not replace xcodebuild on macOS."""
import json
import pathlib
import plistlib
import re
import xml.etree.ElementTree as ET

root = pathlib.Path(__file__).resolve().parents[1]
text = (root / 'HSJaya.xcodeproj/project.pbxproj').read_text(encoding='utf-8')
tokens = re.findall(r'//[^\n]*|"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,]+', text)
tokens = [t for t in tokens if not t.startswith('//')]
index = 0

def take(expected=None):
    global index
    token = tokens[index]
    index += 1
    if expected is not None:
        assert token == expected, (token, expected, index)
    return token

def value():
    token = take()
    if token == '{':
        result = {}
        while tokens[index] != '}':
            key = json.loads(take())
            take('=')
            result[key] = value()
            take(';')
        take('}')
        return result
    if token == '(':
        result = []
        while tokens[index] != ')':
            result.append(value())
            if tokens[index] != ')':
                take(',')
        take(')')
        return result
    return json.loads(token)

project = value()
assert index == len(tokens)
objects = project['objects']
assert objects[project['rootObject']]['isa'] == 'PBXProject'
for obj in objects.values():
    for key in ['children', 'buildPhases', 'targets', 'buildConfigurations']:
        for ref in obj.get(key, []):
            assert ref in objects, (key, ref)
    for key in ['fileRef', 'mainGroup', 'productRefGroup', 'productReference', 'buildConfigurationList']:
        if key in obj:
            assert obj[key] in objects, (key, obj[key])
    if obj['isa'] == 'PBXFileReference' and obj.get('sourceTree') == '<group>':
        assert (root / 'HSJaya' / obj['path']).exists(), obj['path']
    if obj['isa'] in ['PBXSourcesBuildPhase', 'PBXResourcesBuildPhase']:
        for ref in obj['files']:
            assert objects[ref]['isa'] == 'PBXBuildFile'
configs = [v for v in objects.values() if v['isa'] == 'XCBuildConfiguration' and 'INFOPLIST_FILE' in v['buildSettings']]
assert len(configs) == 2
info = plistlib.loads((root / 'HSJaya/Info.plist').read_bytes())
assert info['CFBundleShortVersionString'] == '1.3.0'
assert info['NSBluetoothAlwaysUsageDescription']
for obj in configs:
    assert obj['buildSettings']['MARKETING_VERSION'] == '1.3.0'
    assert obj['buildSettings']['DEVELOPMENT_TEAM'] == ''
plistlib.loads((root / 'HSJaya/PrivacyInfo.xcprivacy').read_bytes())
ET.parse(root / 'HSJaya.xcodeproj/xcshareddata/xcschemes/HSJaya.xcscheme')
for file in (root / 'HSJaya/Assets.xcassets').rglob('Contents.json'):
    json.loads(file.read_text())
print('PASS: OpenStep project structure/references, resources, version metadata, plist, scheme XML, asset catalog.')
print('Apple SDK compilation, signing and iPhone hardware tests are still required.')
