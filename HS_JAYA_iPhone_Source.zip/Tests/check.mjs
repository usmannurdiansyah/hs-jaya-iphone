import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const P = require('../HSJaya/Native/protocol.js');
let checks = 0;
function eq(a,b) { assert.deepEqual(a,b); checks++; }
function ok(a) { assert.ok(a); checks++; }

// Byte identity is stronger than screenshots for detecting unintended UI edits.
const manifest = JSON.parse(fs.readFileSync(path.join(root,'Tests/original-assets.sha256.json')));
for (const [file,hash] of Object.entries(manifest)) {
  eq(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'HSJaya/Web',file))).digest('hex'),hash);
}
const cases = [
  ['RGB HYBRID','CUSTOM'],['HS-JAYA 5A','CUSTOM'],['LEDCAR-02','B_COMPACT'],['LEDDMX-04','B_COMPACT'],
  ['LEDCAR-01','B_CLASSIC'],['LEDDMX','B_CLASSIC'],['LEDBLE','A_GENERIC'],['LEDCAR-00','A_GENERIC'],['Other','UNKNOWN']
];
for (const [name,p] of cases) eq(P.classify(name,false),p);
eq(P.classify('Other',true),'CUSTOM');
// Golden bytes transcribed from the recovered Protocol.java, not from the port.
eq(P.simple('CUSTOM',3,73,4),[123,3,73,0,0,0,0,4,191]);
eq(P.simple('B_COMPACT',1,75,3),[123,1,75,0,255,255,255,255,191]);
eq(P.simple('B_CLASSIC',1,75,3),[123,255,1,24,75,1,255,255,191]);
eq(P.simple('A_GENERIC',3,210,3),[126,255,3,210,3,255,255,255,239]);
eq(P.simple('UNKNOWN',8,13,1),[123,255,8,13,255,255,255,255,191]);
eq(P.rgb('CUSTOM',17,34,51,5),[123,7,17,34,51,0,0,5,191]);
eq(P.rgb('B_COMPACT',17,34,51,3),[123,7,17,34,51,0,255,255,191]);
eq(P.rgb('B_CLASSIC',17,34,51,3),[123,255,7,17,34,51,0,255,191]);
eq(P.rgb('A_GENERIC',17,34,51,3),[126,255,5,3,17,34,51,255,239]);
eq(P.pixel('CUSTOM',1000),[123,5,0,3,232,0,0,3,191]);
eq(P.pixel('B_CLASSIC',1000),[123,255,5,4,3,232,1,255,191]);
eq(P.rem('CUSTOM',1,70),[123,1,70,4,0,0,0,3,191]);
for (const profile of ['CUSTOM','B_COMPACT','B_CLASSIC','A_GENERIC']) {
  for (let mode=1;mode<=210;mode++) {
    const a=P.simple(profile,3,mode,3); eq(a.length,9);
    eq(a[profile==='CUSTOM'||profile==='B_COMPACT'?2:3],mode);
    for (const channel of [1,2,4,5]) {
      const b=P.simple(profile,3,mode,channel);
      if (profile==='CUSTOM') {eq(b[7],channel);eq(b[2],mode);} else eq(b,null);
    }
  }
}
for (const count of [0,1,120,170,255,256,680,999,1000,1024,1025]) {
  const n=Math.max(1,Math.min(1024,count));
  for (const p of ['CUSTOM','B_COMPACT','B_CLASSIC']) {
    const b=P.pixel(p,count);const offset=p==='B_CLASSIC'?4:3;eq(b[offset]*256+b[offset+1],n);
  }
}
eq(P.crc([...Buffer.from('123456789')]),0x29b1);
for (const length of [1,13,14,210,1199,1200]) {
  const data=Array.from({length},(_,i)=>i%210+1),text=data.join(',');
  eq(P.collectDecode(text),data);
  const packets=P.collectPackets(data,5,0x1234);
  eq(packets[0].slice(0,7),[197,1,52,18,5,length&255,length>>8]);
  eq(packets.at(-1),[197,3,52,18]);
  eq(packets.slice(1,-1).flatMap(p=>p.slice(7)),data);
  for (const p of packets) ok(p.length<=20);
}
for (const text of ['', '0','211','1,','1.5',Array(1201).fill(1).join(',')]) {assert.throws(()=>P.collectDecode(text));checks++;}
const config={channel:'ALL',area:1000,head:5,tail:8,speed:75,duration:5,mode:50,color:'#112233',slot:255};
const decoded=P.customDecode(JSON.stringify([config]));
eq(decoded,[3,232,3,5,0,8,0,75,5,50,17,34,51,255]);
const flagged=P.customDecode(JSON.stringify([{...config,channel:'4',reverse:true,bounce:true,tailBack:false,tailFront:true}]));
eq(flagged[0],245);
eq(P.customPackets(decoded,52,false)[0][4],2);
eq(P.customPackets(flagged,52,true)[0][4],3);
eq(P.customPackets(flagged,52,true).at(-1),[198,6,52,0]);
for (const patch of [{channel:'5'},{mode:51},{area:1001},{head:0},{tail:-1},{slot:10},{color:'bad'},{duration:61}]) {assert.throws(()=>P.customDecode(JSON.stringify([{...config,...patch}])));checks++;}

function harness() {
  let serial=0; const timers=new Map(), messages=[],callbacks=[], events={};
  const window={HSProtocol:P,addEventListener:(type,fn)=>{events[type]=fn;},webkit:{messageHandlers:{hsjaya:{postMessage:message=>{
    messages.push(JSON.parse(JSON.stringify(message)));
    queueMicrotask(()=>window.__hsIOSReceive({type:'reply',id:message.id}));
  }}}}};
  for(const n of ['hsBleMultiStatus','hsCollectUpload','hsCollectStatus','hsCollectStopped','hsCustomStatus']) window[n]=(...args)=>callbacks.push([n,...args]);
  const context=vm.createContext({window,console,setTimeout:(fn,ms)=>{const id=++serial;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id)});
  vm.runInContext(fs.readFileSync(path.join(root,'HSJaya/Native/ios-bridge.js'),'utf8'),context);
  const emit=e=>window.__hsIOSReceive(e);
  const chars=['FFE1','7DB10001-7E68-4E55-A8D3-B8096B25B5A0','7DB10002-7E68-4E55-A8D3-B8096B25B5A0','7DB20001-7E68-4E55-A8D3-B8096B25B5A0','7DB20002-7E68-4E55-A8D3-B8096B25B5A0'];
  const ready=(device,name,custom=false,characteristics=chars)=>emit({type:'ready',device,name,custom,characteristics});
  const notify=(device,magic,token,data,count,checksum,other=[])=>emit({type:'notification',device,characteristic:magic===197?chars[2]:chars[4],bytes:[magic,2,token&255,token>>8,...data,count&255,count>>8,checksum&255,checksum>>8,...other]});
  return {api:window.HsNative,window,messages,callbacks,timers,events,emit,ready,notify,chars};
}
const flush=async()=>{for(let i=0;i<60;i++)await Promise.resolve();};
const h=harness();
eq(Object.keys(h.api).sort(),['connect','disconnect','send','rgb','pixel','remSetting','subareaDouble','collectSend','collectCancel','modePreview','customSend','customPreview','customStop','customColor','ota','exit'].sort());
h.events.load(); const auto=[...h.timers.values()].find(t=>t.ms===550);ok(auto);auto.fn();await flush();eq(h.messages.at(-1).method,'connect');
h.ready('custom','HS JAYA',true);h.ready('stock','LEDCAR-02');
h.api.send(3,73,4);await flush();eq(h.messages.filter(m=>m.method==='write').map(m=>m.device),['custom']);
h.api.pixel(680);await flush();eq(h.messages.filter(m=>m.method==='write').slice(-2).map(m=>m.bytes),[P.pixel('CUSTOM',680),P.pixel('B_COMPACT',680)]);
h.api.subareaDouble(1);await flush();const sub=[...h.timers.values()].find(t=>t.ms===160);ok(sub);sub.fn();await flush();eq(h.messages.filter(m=>m.bytes?.[1]===20).length,2);

const c=harness();c.ready('one','HS JAYA',true);c.ready('two','HS JAYA B',true);
c.api.collectSend('1,73,210',3,100);await flush();
eq(c.callbacks.filter(x=>x[0]==='hsCollectUpload').length,0); // Submission is not firmware acknowledgement.
c.notify('one',197,100,[0,0,1,3],3,P.crc([1,73,210]));await flush();
eq(c.callbacks.filter(x=>x[0]==='hsCollectUpload').length,0);
c.notify('two',197,100,[0,0,1,3],3,P.crc([1,73,210]));await flush();
eq(c.callbacks.filter(x=>x[0]==='hsCollectUpload').at(-1),['hsCollectUpload',100,true]);
c.api.collectSend('210',5,101);await flush();
c.notify('one',197,100,[0,0,1,3],3,P.crc([1,73,210]));await flush(); // Stale token ignored.
eq(c.callbacks.filter(x=>x[0]==='hsCollectUpload'&&x[1]===101).length,0);
c.api.collectCancel();await flush();c.notify('one',197,101,[0,0,210,5],1,P.crc([210]));await flush();
eq(c.callbacks.filter(x=>x[0]==='hsCollectUpload'&&x[1]===101).length,0);

const stock=harness();stock.ready('s','LEDCAR-02');stock.api.collectSend('1,73,210',2,7);await flush();
eq(stock.callbacks.find(x=>x[0]==='hsCollectStatus'),['hsCollectStatus',7,5,0,1,2,3]);
const tick=[...stock.timers.values()].find(t=>t.ms===3000);ok(tick);tick.fn();await flush();
eq(stock.callbacks.filter(x=>x[0]==='hsCollectStatus').at(-1),['hsCollectStatus',7,5,1,73,2,3]);

const u=harness();u.ready('one','HS JAYA',true);
u.api.customPreview(JSON.stringify([config]),200);await flush();
eq(u.messages.filter(m=>m.method==='write').at(-1).bytes,[198,6,200,0]);
eq(u.callbacks.filter(x=>x[0]==='hsCustomStatus').length,0);
u.api.customColor(200,9,8,7);await flush();
u.notify('one',198,200,[0,0,50,255],1,P.crc(decoded));await flush();
eq(u.callbacks.filter(x=>x[0]==='hsCustomStatus').at(-1),['hsCustomStatus',200,2,0,50,255,1]);
eq(u.messages.filter(m=>m.method==='write').at(-1).bytes,[198,5,200,0,9,8,7]);
// A new preview is queued until the previous upload is acknowledged. Intermediate edits collapse.
u.api.customPreview(JSON.stringify([config]),201);await flush();
const before=u.messages.length;u.api.customPreview(JSON.stringify([config]),202);u.api.customPreview(JSON.stringify([config]),203);await flush();eq(u.messages.length,before);
u.notify('one',198,201,[0,0,50,255],1,P.crc(decoded));await flush();
eq(u.messages.filter(m=>m.method==='write').at(-1).bytes,[198,6,203,0]);
ok(!u.messages.some(m=>m.bytes?.[0]===198&&m.bytes?.[1]===1&&m.bytes?.[2]===202));
u.api.customStop(203);await flush();ok(u.messages.some(m=>JSON.stringify(m.bytes)==='[198,4,203,0]'));
const beforeStatus=u.callbacks.length;u.notify('one',198,203,[0,0,50,255],1,P.crc(decoded));await flush();eq(u.callbacks.length,beforeStatus);

const bad=harness();bad.ready('one','HS JAYA',true);bad.api.collectSend('0',3,9);await flush();eq(bad.callbacks.at(-1),['hsCollectUpload',9,false]);
bad.api.customSend(JSON.stringify([config]),10);await flush();bad.emit({type:'disconnected',device:'one'});await flush();
ok(bad.callbacks.some(x=>x[0]==='hsCustomStatus'&&x[1]===10&&x[2]===4));
const timeout=harness();timeout.ready('one','HS JAYA',true);timeout.api.collectSend('1',3,11);await flush();
for(const [id,t]of [...timeout.timers])if(t.ms===12000){timeout.timers.delete(id);t.fn();}await flush();
eq(timeout.callbacks.filter(x=>x[0]==='hsCollectUpload').at(-1),['hsCollectUpload',11,false]);
const crcGuard=harness();crcGuard.ready('one','HS JAYA',true);crcGuard.api.customSend(JSON.stringify([config]),40);await flush();
crcGuard.notify('one',198,40,[0,0,50,255],1,P.crc(decoded)^1);await flush();
eq(crcGuard.callbacks.filter(x=>x[0]==='hsCustomStatus').length,0);
crcGuard.api.customPreview(JSON.stringify([config]),41);await flush();
const pendingTimeouts=[...crcGuard.timers].filter(([,t])=>t.ms===12000);
for(const [id,t]of pendingTimeouts){crcGuard.timers.delete(id);t.fn();}await flush();
ok(crcGuard.messages.some(m=>m.bytes?.[0]===198&&m.bytes?.[1]===1&&m.bytes?.[2]===41));
const unsupported=harness();unsupported.ready('s','LEDCAR-02',false,['FFE1']);unsupported.api.customSend(JSON.stringify([config]),42);await flush();
eq(unsupported.callbacks.filter(x=>x[0]==='hsCustomStatus').at(-1),['hsCustomStatus',42,4,2,0,255,1]);
console.log(`PASS: ${checks} assertions; ${Object.keys(manifest).length} original assets unchanged; wire vectors, 210 modes, pixel bounds, upload ACK/CRC/token/cancellation, queued preview, live color, stock Collect, disconnect and timeout.`);
console.log('Not covered here: Apple SDK type-check/build/signing, WebKit visual rendering, real BLE radio, background execution, iPhone hardware.');
