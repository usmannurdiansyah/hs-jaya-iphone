#!/bin/bash
# Run on a Mac/Xcode host. Produces an UNSIGNED IPA for signing on the user's PC.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
  echo "This build needs a macOS host with Xcode. No IPA was generated." >&2
  exit 1
fi

node Tests/check.mjs
python3 Tests/check_project.py
xcodebuild -version

OUT="$ROOT/build-iphone"
ARCHIVE="$OUT/HSJaya.xcarchive"
PACKAGE="$OUT/package"
IPA="$OUT/HS_JAYA_iPhone_UNSIGNED.ipa"

# Refuse to overwrite old archives/artifacts; preserve previous build evidence.
if [[ -e "$OUT" ]]; then
  echo "build-iphone already exists. Use a clean checkout or rename that folder first." >&2
  exit 1
fi
mkdir -p "$OUT"

xcodebuild \
  -project HSJaya.xcodeproj \
  -scheme HSJaya \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -sdk iphoneos \
  -archivePath "$ARCHIVE" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  archive

APP="$ARCHIVE/Products/Applications/HSJaya.app"
test -d "$APP"
plutil -lint "$APP/Info.plist"
EXECUTABLE="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APP/Info.plist")"
lipo "$APP/$EXECUTABLE" -verify_arch arm64
test -s "$APP/Web/index.html"
test -s "$APP/Native/ios-bridge.js"

mkdir -p "$PACKAGE/Payload"
ditto "$APP" "$PACKAGE/Payload/HSJaya.app"
ditto -c -k --keepParent "$PACKAGE/Payload" "$IPA"

python3 - "$IPA" <<'PY'
import pathlib, sys, zipfile
p = pathlib.Path(sys.argv[1])
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    required = ['Payload/HSJaya.app/Info.plist', 'Payload/HSJaya.app/HSJaya',
                'Payload/HSJaya.app/Web/index.html', 'Payload/HSJaya.app/Native/ios-bridge.js']
    for name in required:
        assert name in z.namelist(), name
print('Created UNSIGNED IPA:', p.name, p.stat().st_size, 'bytes')
print('It must be signed for your iPhone before installation. No hardware test has run.')
PY
shasum -a 256 "$IPA" > "$OUT/HS_JAYA_iPhone_UNSIGNED.ipa.sha256"
printf '%s\n' "$IPA"
