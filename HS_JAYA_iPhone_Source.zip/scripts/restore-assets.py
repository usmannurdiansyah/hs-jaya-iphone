"""Restore byte-identical APK UI assets for the cloud build, with an exact allowlist."""
import hashlib
import json
import pathlib
import sys
import zipfile

root = pathlib.Path(__file__).resolve().parents[1]
archive = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'HS_JAYA_UI_ASSETS.zip'
manifest = json.loads((root / 'Tests/original-assets.sha256.json').read_text())
expected = {'HSJaya/Web/' + name: digest for name, digest in manifest.items()}
expected['HSJaya/Assets.xcassets/AppIcon.appiconset/AppIcon.png'] = '65fb5fc82bd5456d7c289c26b6cd6d80691b4615ac9b144c1c3599c06781c4ac'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None, 'Asset archive CRC error'
    assert len(z.namelist()) == len(expected) and set(z.namelist()) == set(expected), 'Unexpected/missing archive entry'
    assert sum(i.file_size for i in z.infolist()) < 32 * 1024 * 1024, 'Oversized archive'
    verified = []
    for name, digest in expected.items():
        data = z.read(name)
        assert hashlib.sha256(data).hexdigest() == digest, 'Asset hash mismatch: ' + name
        verified.append((root / name, data))
    for dest, data in verified:
        if dest.exists() and dest.read_bytes() == data:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
print('PASS: restored/verified 105 original UI assets and the original-image iOS app icon')
