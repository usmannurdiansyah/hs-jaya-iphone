# Pasang HS JAYA ke iPhone dari Windows

**Status saat dokumen disiapkan: belum ada IPA.** Repository `usmannurdiansyah/hs-jaya-iphone` sudah dapat diakses dan bersifat Public sesuai pilihan pengguna. Jangan mengganti ekstensi APK menjadi IPA.

## Tahap yang dikerjakan di cloud

Pengguna memilih **Public**, sehingga file yang diunggah dapat dilihat orang lain. Unggah `HS_JAYA_iPhone_Source.zip` ke folder utama repository dan isi `.github/workflows/build-iphone.yml` memakai YML terbaru. Workflow memakai runner Mac GitHub, mengekstrak seluruh project, memverifikasi identitas aset lewat tests, lalu `xcodebuild archive` untuk iPhone arm64. Jika compiler menolak source, error harus diperbaiki dan build diulang; belum ada bukti compile berhasil saat dokumen ini dibuat.

Workflow hanya dapat dijalankan manual melalui GitHub Actions → **Build HS JAYA iPhone IPA → Run workflow**. Upload/commit tidak otomatis memulai build. Workflow dibatasi 20 menit, akses repository read-only saat build, artifact disimpan 7 hari. Penggunaan runner mengikuti kuota dan aturan billing akun GitHub; belum ada build yang dijalankan atau biaya yang dibuat oleh pekerjaan ini.

Hasil yang direncanakan: `HS_JAYA_iPhone_UNSIGNED.ipa`. Ini aplikasi iPhone hasil compile **tanpa tanda tangan**, yang kemudian ditandatangani untuk perangkat pengguna melalui PC. Artifact unsigned tidak boleh disebut langsung siap pasang.

## Setelah IPA benar-benar berhasil dibuat

1. Unduh [Sideloadly resmi](https://sideloadly.io/) untuk Windows dan ikuti kebutuhan driver Apple pada petunjuk resminya. Pemasangan tool belum dilakukan oleh pekerjaan ini.
2. Sambungkan iPhone ke PC dengan kabel, buka kunci, lalu pilih **Trust/Percayai** ketika diminta.
3. Buka Sideloadly, pilih iPhone dan masukkan file IPA hasil build.
4. Masuk menggunakan Apple ID Anda **langsung pada aplikasi di PC**, bukan melalui chat. Signing ini mendaftarkan aplikasi/perangkat ke akun Apple tersebut.
5. Jalankan pemasangan. Ikuti permintaan verifikasi, profil developer, dan Developer Mode dari iOS bila diminta. Nama menu bergantung bahasa/versi iOS.
6. Setelah aplikasi terbuka, izinkan Bluetooth dan uji dengan modul HS JAYA. Hasil pemeriksaan komputer belum membuktikan koneksi radio/fungsi pada perangkat.

Menurut [FAQ Sideloadly](https://sideloadly.io/faq), signing memakai akun Apple gratis umumnya berlaku **7 hari** dan perlu diperbarui. Metode ini belum diuji pada iPhone pengguna. Untuk distribusi yang dikelola lewat TestFlight/App Store, gunakan signing dan akun Apple Developer yang sesuai.

Tidak ada password Apple, sertifikat, atau data perangkat yang dimasukkan ke repository/workflow. Tampilan aplikasi asli tetap dipertahankan.

Referensi runner cloud: [GitHub-hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners).
