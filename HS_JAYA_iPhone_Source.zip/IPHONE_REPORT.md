# HS JAYA iPhone — laporan

Tanggal: 19 Oktober 2026.

Sumber: `D:\hsjaya.apk`, 19.579.827 byte.
SHA256: `bdfb585cb96840301ae2c52e8cbbe4411569eef3c5a5b5d1a172a4941b77bd24`.
Package Android: `com.hsjaya.led`, manifest `1.3.0-multi-mundur-collect` (versionCode 16). Metadata iOS memakai 1.3.0. Teks About lama 1.2.7 tetap dibiarkan agar file tampilan APK tidak diubah.

## Hasil

| Bagian | Status |
|---|---|
| Project Xcode, iPhone iOS 15+ | Dibuat; belum dikompilasi dengan Apple SDK |
| Tampilan/aset APK | 105 file identik SHA256, tidak diedit |
| Penghubung HsNative | 16 metode disediakan, termasuk Collect/Custom |
| Format paket dasar | Dipindahkan dari Protocol.java hasil pemulihan APK; golden bytes diuji |
| Mode 1–210 / empat kanal | Encoding diuji lokal; bukan uji efek pada modul |
| Pixel Setting | UI asli tetap; encoder mempertahankan clamp Android 1–1024. Ini bukan perubahan batas firmware |
| Transport iOS | Core Bluetooth, antrean per perangkat, respons tulis/backpressure, notifikasi, timeout, serta disconnect |
| Uji Node | PASS, 6.333 assertions; transport tiruan |
| Sintaks Swift | Tiga file lolos parser sintaks lokal; **bukan type-check/build Xcode** |
| Build, signing, IPA | BELUM — mesin ini Windows; pengguna belum mempunyai Mac |
| Workflow build Mac cloud | Disiapkan; belum dijalankan karena akses repository belum tersedia |
| Tampilan WebKit iPhone / radio BLE / multi-device / background | BELUM diuji |
| Siap distribusi / siap digunakan | BELUM |

## Implementasi

- UI lama dimuat melalui WKWebView dari file lokal. Adapter diinjeksikan dari file terpisah saat dokumen dibuat; file UI asli tidak diubah.
- UUID kontrol `FFE0/FFE1`; profil CUSTOM, B_COMPACT, B_CLASSIC, A_GENERIC dipertahankan menurut deteksi nama/service APK. Service Custom dan Collect memakai UUID asli APK.
- Frame kontrol 9 byte, urutan channel, RGB, Pixel Setting, REM, SUB AREA double-send, preview, CRC16-CCITT dan framing multipart dipertahankan. Maksimum paket upload 20 byte.
- Collect pada modul stock mengikuti runner 3 detik APK; pada firmware custom memakai notifikasi firmware. Uji background belum dilakukan.
- Custom memakai antrean preview: upload lama diselesaikan/diakui dahulu, kemudian permintaan terbaru. Notifikasi dengan token/count/CRC yang salah tidak dianggap sukses.
- Satu koneksi Core Bluetooth per peripheral dipakai bersama untuk control/Collect/Custom; tidak menyalin mekanisme beberapa BluetoothGatt handle Android. Perubahan ini perlu diuji dengan firmware aktual.
- Bridge dibatasi ke frame utama dan file UI lokal. URL eksternal dibuka di aplikasi sistem. Identitas perangkat iOS memakai UUID sistem, bukan alamat MAC Android.
- Ikon memakai gambar asli APK, diubah ukuran ke format AppIcon Apple. Menu Exit memberi instruksi Home; proses aplikasi tidak dipaksa berhenti.
- Tidak ada PCB, BOM, firmware, source Android master, atau file APK yang ditimpa. Tidak ada pembelian, publikasi, sertifikat, atau signing account yang dibuat.

## Batas penting

Project ini merupakan **port source untuk tahap build dan pengujian**, bukan bukti kompatibilitas iPhone penuh. Parser Swift tidak memeriksa tipe/API Apple. Simulator tidak membuktikan koneksi BLE. Paket/profil tidak boleh dinyatakan lulus hardware sampai build Xcode dan pengujian iPhone + modul selesai. Pengaturan Android yang tersimpan pada ponsel lama tidak otomatis berpindah melalui APK.

Workflow GitHub Actions dan `scripts/build-ipa.sh` disiapkan untuk membuat IPA arm64 unsigned tanpa credential Apple di cloud. Repository `usmannurdiansyah/hs-jaya-iphone` dapat diakses dan dipilih Public oleh pengguna. Pengguna kemudian meminta hanya pengiriman file, tanpa unggah atau menjalankan build oleh agen. Karena itu, paket source lengkap dan YML manual disiapkan untuk diunggah sendiri. Source belum diunggah oleh agen, build belum dijalankan, dan IPA belum dibuat. Signing untuk perangkat tetap harus diselesaikan; petunjuk Windows ada di `INSTALL_IPHONE.md`.

OTA tetap mengarah ke URL asli APK. Dukungan browser iPhone untuk proses OTA belum diperiksa dan tidak dijanjikan.

Referensi Apple: [Core Bluetooth](https://developer.apple.com/documentation/corebluetooth), [penulisan characteristic](https://developer.apple.com/documentation/corebluetooth/cbperipheral/writevalue(_:for:type:)), [WKWebView file lokal](https://developer.apple.com/documentation/webkit/wkwebview/loadfileurl(_:allowingreadaccessto:)), [distribusi/signing](https://developer.apple.com/documentation/xcode/preparing-your-app-for-distribution).
