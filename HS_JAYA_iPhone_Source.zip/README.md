# HS JAYA — iPhone

Project iPhone dari `D:\hsjaya.apk`, bukan APK yang diganti ekstensi.

**Status: source project tersedia; belum dibuild, ditandatangani, atau diuji pada iPhone. Belum ada IPA siap pasang.**

## Tampilan

Seluruh 105 file dalam `HSJaya/Web` disalin utuh dari APK: HTML, CSS, JavaScript, gambar, serta preview. Hash setiap file diperiksa. Tidak ada perubahan warna, tombol, menu, susunan, maupun logika tampilan.

Penghubung iOS ditambahkan terpisah dalam `HSJaya/Native` dan tiga file Swift. Ukuran layar dan rendering WebKit iPhone tetap perlu diperiksa pada perangkat. Dialog izin Bluetooth/pemilih foto berasal dari iOS. Menu Exit tetap ada; iOS menampilkan petunjuk menggunakan Home karena aplikasi tidak boleh menutup prosesnya sendiri.

## Jika belum punya Mac

Jalur yang disiapkan sekarang: **build di Mac cloud GitHub → IPA unsigned → signing dan pemasangan melalui Windows**. Petunjuk ada di [INSTALL_IPHONE.md](INSTALL_IPHONE.md). Repository `usmannurdiansyah/hs-jaya-iphone` memakai Public sesuai pilihan pengguna. IPA belum dihasilkan sampai build berhasil.

Untuk unggah sendiri, gunakan **HS_JAYA_iPhone_Source.zip** lengkap dan file **build-iphone.yml**. Unggah ZIP di folder utama repository; YML di `.github/workflows/build-iphone.yml`. Workflow mengekstrak project ke folder kerja `source` dan hanya berjalan ketika pengguna menekan **Run workflow**. Semua UI, icon, native source, dan tests sudah ada dalam ZIP; tidak perlu archive aset terpisah. ZIP ini bukan file instalasi iPhone.

Alternatifnya, kirim folder project lengkap ke pengembang/jasa build iOS yang memiliki Mac + Xcode untuk build/signing atau TestFlight. Jangan mengirim kata sandi Apple ID di dalam project/chat.

APK ini dan project Windows tidak bisa langsung dipasang ke iPhone. Tidak ada langganan, akun Apple, pembelian, upload, atau publikasi yang dibuat selama pekerjaan ini.

## Build di Mac

1. Buka `HSJaya.xcodeproj` memakai Xcode 16 atau lebih baru. Deployment target iOS 15.0, iPhone, portrait.
2. Target **HSJaya → Signing & Capabilities → Team**: pilih team milik pemilik aplikasi. Automatic signing sudah disiapkan; Team sengaja kosong. Sesuaikan bundle identifier jika sudah terdaftar pada team lain.
3. Pilih iPhone fisik, aktifkan Developer Mode bila diminta, lalu Build/Run. Simulator dapat memeriksa tampilan, tetapi tidak menggantikan uji BLE fisik.
4. Izinkan Bluetooth. Aplikasi mencari perangkat kompatibel otomatis seperti APK asal. Matikan koneksi aplikasi Android saat menguji jika modul hanya menerima satu central.
5. Untuk distribusi: lakukan Archive dan signing sesuai akun Apple/metode distribusi yang dipilih. Project ini tidak berisi sertifikat atau provisioning profile.

Pemeriksaan compile tanpa signing di Mac:

```sh
xcodebuild -project HSJaya.xcodeproj -scheme HSJaya -sdk iphonesimulator -configuration Debug CODE_SIGNING_ALLOWED=NO build
```

## Verifikasi sebelum digunakan

- Bandingkan setiap halaman dengan APK pada ukuran layar iPhone yang dipakai: scroll, keyboard, pemilih foto, roda warna, tombol, preset.
- Uji auto-connect, izin ditolak/diberikan, scan ulang, disconnect/reconnect, modul mati, dan beberapa modul bersamaan.
- Uji LED1–4/ALL, RGB, speed, brightness, Pixel Setting, mode 1–210, Welcome, Standby, SEN, REM, MUNDUR, serta SUB AREA pada profil yang mendukungnya.
- Uji Collect dan Custom pada firmware yang benar-benar menyediakan service tersebut; upload dianggap sukses setelah notifikasi token/count/CRC yang sesuai, bukan setelah kirim saja.
- Uji preview Custom berturut-turut, ubah warna saat upload, Stop, pindah halaman, penyimpanan lokal, dan buka ulang aplikasi.
- Uji perpindahan aplikasi/layar terkunci. Background BLE dan timer stock Collect **belum dijamin**; tidak ditambahkan background capability secara spekulatif.
- OTA tetap membuka URL yang ada pada APK. Halaman dan proses OTA melalui browser iPhone belum divalidasi; tidak ada firmware yang diunggah/diubah.

Tidak ada perubahan PCB, BOM, GPIO, firmware, atau project Android asli. Tidak ada komponen/paket eksternal yang diperlukan oleh aplikasi saat runtime.

## Pemeriksaan lokal

Jalankan `node Tests/check.mjs`. Pengujian mencakup identitas aset, golden packet bytes dari kode Android hasil pemulihan, 210 mode, batas encoding Pixel Setting, CRC, multipart upload, notifikasi/token, timeout, disconnect, pembatalan, antrean preview, serta warna live. Ini pengujian software dengan transport tiruan; **bukan** uji radio/SDK Apple.

Lihat `IPHONE_REPORT.md` untuk batas verifikasi dan asal source.
