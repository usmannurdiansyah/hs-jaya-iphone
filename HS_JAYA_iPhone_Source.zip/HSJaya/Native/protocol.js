/* Wire formats recovered from the supplied HS JAYA APK. No UI code. */
(function (root) {
  'use strict';
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, Math.trunc(n)));
  const byte = n => n & 255;
  const u8 = n => clamp(n, 0, 255);
  const channelCode = n => [1, 2, 4, 5].includes(n);
  const frame = (head, tail, values) => [head, ...values.map(byte), tail];
  const B = (...v) => frame(0x7b, 0xbf, v);
  const A = (...v) => frame(0x7e, 0xef, v);
  const base = (cmd, ch) => B(cmd, 0, 0, 0, 0, 0, ch);
  function classify(name, custom) {
    const n = String(name || '').toUpperCase();
    if (custom || ['RGB HYBRID', 'HS JAYA', 'HS-JAYA'].some(x => n.includes(x))) return 'CUSTOM';
    if (['LEDCAR-02', 'LEDDMX-02', 'LEDDMX-04'].some(x => n.startsWith(x))) return 'B_COMPACT';
    if (n.startsWith('LEDDMX') || n.startsWith('LEDCAR-01')) return 'B_CLASSIC';
    if (n.startsWith('LEDCAR-00') || n.startsWith('LEDBLE')) return 'A_GENERIC';
    return n.startsWith('LEDCAR') ? 'B_COMPACT' : 'UNKNOWN';
  }
  function simple(p, cmd, value, ch) {
    if (p === 'CUSTOM') { const b = base(cmd, ch); b[2] = byte(value); return b; }
    if (cmd === 8) return B(255, 8, u8(value), 255, 255, 255, 255);
    if (channelCode(ch)) return null;
    const v = u8(value), c = byte(cmd);
    if (p === 'B_COMPACT') {
      if ([1, 2].includes(c)) return B(c, v, 0, 255, 255, 255, 255);
      if ([3, 4, 13, 24, 25, 26, 29].includes(c)) return B(cmd, v, 255, 255, 255, 255, 255);
    }
    if (p === 'B_CLASSIC') {
      if (c === 1) return B(255, 1, Math.trunc(v * 32 / 100), v, 1, 255, 255);
      if (c === 2) return B(255, 2, v, 0, 255, 255, 255);
      if ([3, 4, 13, 24, 25, 26, 29].includes(c)) return B(255, cmd, v, 255, 255, 255, 255);
    }
    if (p === 'A_GENERIC') {
      if ([1, 2].includes(c)) return A(255, c, v, 0, 255, 255, 255);
      if (c === 3) return A(255, 3, v, 3, 255, 255, 255);
      if (c === 4) return A(255, 4, v, 255, 255, 255, 255);
    }
    return null;
  }
  function rgb(p, r, g, b, ch) {
    [r, g, b] = [r, g, b].map(u8);
    if (p === 'CUSTOM') { const a = base(7, ch); a.splice(2, 3, r, g, b); return a; }
    if (channelCode(ch)) return null;
    if (p === 'B_COMPACT') return B(7, r, g, b, 0, 255, 255);
    if (p === 'B_CLASSIC') return B(255, 7, r, g, b, 0, 255);
    if (p === 'A_GENERIC') return A(255, 5, 3, r, g, b, 255);
    return null;
  }
  function pixel(p, count) {
    const n = clamp(count, 1, 1024), hi = n >> 8, lo = byte(n);
    if (p === 'CUSTOM') { const a = base(5, 3); a[3] = hi; a[4] = lo; return a; }
    if (p === 'B_COMPACT') return B(5, 1, hi, lo, 255, 255, 255);
    if (p === 'B_CLASSIC') return B(255, 5, 4, hi, lo, 1, 255);
    return null;
  }
  function rem(p, cmd, value) {
    if (p !== 'CUSTOM') return null;
    const a = simple(p, cmd, value, 3); a[3] = 4; return a;
  }
  function crc(data) {
    let c = 0xffff;
    for (const b of data) { c ^= byte(b) << 8; for (let j = 0; j < 8; j++) c = ((c << 1) ^ ((c & 0x8000) ? 0x1021 : 0)) & 0xffff; }
    return c;
  }
  function collectDecode(text) {
    const modes = String(text).split(',');
    if (!modes.length || modes.length > 1200) throw Error('count');
    return modes.map(s => { if (!/^[+-]?\d+$/.test(s)) throw Error('mode'); const n = Number(s); if (n < 1 || n > 210) throw Error('mode'); return n; });
  }
  function customDecode(text) {
    const rows = JSON.parse(text);
    if (!Array.isArray(rows) || rows.length < 1 || rows.length > 10) throw Error('count');
    const bounded = (r, k, lo, hi) => { const n = r[k]; if (!Number.isInteger(n) || n < lo || n > hi) throw Error(k); return n; };
    return rows.flatMap(r => {
      let ch = r.channel === 'ALL' ? 3 : [1, 2, 4, 5][Number(r.channel) - 1];
      if (ch === undefined) throw Error('channel');
      if (r.reverse) ch |= 64; if (r.bounce) ch |= 128;
      if (r.tailBack === false) ch |= 16; if (r.tailFront) ch |= 32;
      if (!/^#[0-9a-fA-F]{6}$/.test(r.color)) throw Error('color');
      const color = parseInt(r.color.slice(1), 16), slot = bounded(r, 'slot', 0, 255);
      if (slot > 9 && slot !== 255) throw Error('slot');
      const area = bounded(r, 'area', 1, 1000), head = bounded(r, 'head', 1, 1000), tail = bounded(r, 'tail', 0, 1000);
      return [ch, byte(area), area >> 8, byte(head), head >> 8, byte(tail), tail >> 8,
        bounded(r, 'speed', 1, 100), bounded(r, 'duration', 1, 60), bounded(r, 'mode', 1, 50),
        byte(color >> 16), byte(color >> 8), byte(color), slot];
    });
  }
  function upload(magic, data, target, token, preview = false) {
    const lo = byte(token), hi = byte(token >> 8), sum = crc(data);
    const out = [[magic, 1, lo, hi, target, byte(data.length), data.length >> 8, byte(sum), sum >> 8]];
    for (let offset = 0; offset < data.length; offset += 13) {
      const chunk = data.slice(offset, offset + 13);
      out.push([magic, 2, lo, hi, byte(offset), offset >> 8, chunk.length, ...chunk]);
    }
    out.push([magic, preview ? 6 : 3, lo, hi]); return out;
  }
  function customPackets(data, token, preview) {
    let version = 2;
    for (let i = 0; i < data.length; i += 14) if (data[i] & 0xf0) version = 3;
    return upload(0xc6, data, version, token, preview);
  }
  const api = {classify, simple, rgb, pixel, rem, crc, collectDecode, customDecode, customPackets,
    collectPackets: (data, target, token) => upload(0xc5, data, target, token)};
  root.HSProtocol = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
