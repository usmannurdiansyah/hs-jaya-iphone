/* iOS transport adapter. Original APK HTML/CSS/JS/assets remain byte-identical. */
(function () {
  'use strict';
  const P = window.HSProtocol;
  const UUID = {
    tx:'FFE1',
    collectRX:'7DB10001-7E68-4E55-A8D3-B8096B25B5A0', collectStatus:'7DB10002-7E68-4E55-A8D3-B8096B25B5A0',
    customRX:'7DB20001-7E68-4E55-A8D3-B8096B25B5A0', customStatus:'7DB20002-7E68-4E55-A8D3-B8096B25B5A0'
  };
  const devices = new Map(), requests = new Map();
  const customSessions = new Map();
  let sequence = 0, detected = 0, lastText = 'Belum terhubung';
  let collectEpoch = 0, customEpoch = 0, collectRun = null, customRun = null;
  const call = (name, ...args) => { if (typeof window[name] === 'function') window[name](...args); };
  function rpc(method, args = {}) {
    return new Promise((resolve, reject) => {
      const id = ++sequence;
      const timeout = setTimeout(() => { requests.delete(id); reject(Error('Bluetooth timeout')); }, 12000);
      requests.set(id, {resolve, reject, timeout});
      window.webkit.messageHandlers.hsjaya.postMessage({id, method, ...args});
    });
  }
  const active = () => [...devices.values()].filter(d => d.ready && d.profile !== 'UNKNOWN');
  function status(text) {
    if (text) lastText = text;
    const all = [...devices.values()].filter(d => d.ready);
    const custom = all.filter(d => d.profile === 'CUSTOM').length;
    const dmx = all.filter(d => d.profile !== 'CUSTOM' && d.name.toUpperCase().includes('LEDDMX')).length;
    call('hsBleMultiStatus', lastText, Math.max(detected, all.length), all.length, custom, all.length - custom - dmx, dmx);
  }
  function summary() {
    const n = [...devices.values()].filter(d => d.ready).length;
    status(n ? `${Math.max(detected,n)} perangkat terdeteksi · ${n} terhubung` : detected ? `${detected} perangkat terdeteksi · menghubungkan otomatis…` : 'Belum terhubung');
  }
  const write = (d, characteristic, bytes) => rpc('write', {device:d.id, characteristic, bytes});
  const subscribe = (d, characteristic) => rpc('subscribe', {device:d.id, characteristic});
  function basic(method, ...args) {
    for (const d of active()) {
      const packet = P[method](d.profile, ...args);
      if (packet) write(d, UUID.tx, packet).catch(e => status(e.message));
    }
  }
  const word = (b, offset) => b[offset] | (b[offset + 1] << 8);
  function clearRun(run) {
    if (!run) return;
    for (const s of run.sessions.values()) { clearTimeout(s.timer); clearTimeout(s.stockTimer); }
  }
  function collectFail(run) {
    if (collectRun !== run || run.failed) return;
    run.failed = true; clearRun(run); call('hsCollectUpload', run.token, false);
  }
  function collectAccept(run, s) {
    if (s.accepted) return;
    s.accepted = true; clearTimeout(s.timer); run.pending.delete(s.id);
    if (!run.pending.size && !run.failed) call('hsCollectUpload', run.token, true);
  }
  function cancelCollect() { ++collectEpoch; clearRun(collectRun); collectRun = null; }
  function collectStart(text, target, token) {
    cancelCollect();
    const run = {epoch:collectEpoch, token, target, sessions:new Map(), pending:new Set(), failed:false};
    collectRun = run;
    let data;
    try { data = P.collectDecode(text); if (!Number.isInteger(target) || target < 1 || target > 5) throw Error('target'); }
    catch (_) { collectFail(run); return; }
    const selected = active();
    if (!selected.length) { collectFail(run); return; }
    for (const d of selected) { run.pending.add(d.id); run.sessions.set(d.id, {id:d.id, data, checksum:P.crc(data), accepted:false}); }
    const firstCustom = selected.find(d => d.profile === 'CUSTOM');
    for (const d of selected) {
      const s = run.sessions.get(d.id);
      if (d.profile !== 'CUSTOM') {
        let index = 0;
        const tick = async () => {
          if (collectRun !== run || run.failed) return;
          try {
            if (!d.ready) throw Error('disconnected');
            const packet = P.simple(d.profile, 3, data[index], 3); if (!packet) throw Error('unsupported');
            await write(d, UUID.tx, packet);
            if (collectRun !== run || run.failed) return;
            collectAccept(run, s);
            if (!firstCustom && selected[0].id === d.id) call('hsCollectStatus', token, 5, index, data[index], target, data.length);
            if (data.length > 1) { index = (index + 1) % data.length; s.stockTimer = setTimeout(tick, 3000); }
          } catch (_) { collectFail(run); }
        }; tick(); continue;
      }
      (async () => {
        try {
          await subscribe(d, UUID.collectStatus);
          for (const packet of P.collectPackets(data, target, token)) {
            if (collectRun !== run || run.failed) return;
            await write(d, UUID.collectRX, packet);
          }
          if (collectRun === run && !s.accepted && !run.failed) s.timer = setTimeout(() => collectFail(run), 12000);
        } catch (_) { collectFail(run); }
      })();
    }
  }
  function customFail(run, code) {
    const alreadyFailed = run.failed; run.failed = true;
    for (const s of run.sessions.values()) { clearTimeout(s.timer); if (s.finish) s.finish(); }
    if (customRun !== run || alreadyFailed) return;
    clearRun(run); call('hsCustomStatus', run.token, 4, code, 0, 255, run.count);
  }
  function customReport(run) {
    if (customRun !== run || run.failed || run.pending.size) return;
    const first = [...run.sessions.values()].find(s => s.latest);
    if (!first) { customFail(run, 2); return; }
    const b = first.latest;
    call('hsCustomStatus', run.token, b[1], word(b, 4), b[6], b[7], run.count);
  }
  function customStart(text, token, preview) {
    // Finish an in-flight upload before the newest queued preview starts, as on Android.
    ++customEpoch;
    const run = {epoch:customEpoch, token, count:0, checksum:0, sessions:new Map(), pending:new Set(), failed:false};
    customRun = run;
    let data;
    try { data = P.customDecode(text); run.count = data.length / 14; run.checksum = P.crc(data); }
    catch (_) { customFail(run, 8); return; }
    const selected = active();
    if (!selected.length) { customFail(run, 1); return; }
    for (const d of selected) {
      run.pending.add(d.id);
      const s = {id:d.id, accepted:false};
      s.done = new Promise(resolve => { s.finish = resolve; }); run.sessions.set(d.id, s);
    }
    for (const d of selected) {
      const s = run.sessions.get(d.id);
      const prior = customSessions.get(d.id);
      (async () => {
        try {
          if (prior && !prior.s.accepted) await prior.s.done;
          if (customRun !== run || run.failed) { s.finish(); return; }
          if (!d.characteristics.includes(UUID.customRX) || !d.characteristics.includes(UUID.customStatus)) {
            run.pending.delete(d.id); s.finish(); customReport(run); return;
          }
          customSessions.set(d.id, {run, s});
          await subscribe(d, UUID.customStatus);
          for (const packet of P.customPackets(data, token, preview)) {
            if (customSessions.get(d.id)?.run !== run || run.failed) { s.finish(); return; }
            await write(d, UUID.customRX, packet);
          }
          if (!s.accepted && !run.failed) s.timer = setTimeout(() => customFail(run, 6), 12000);
        } catch (_) { customFail(run, 5); }
      })();
    }
  }
  function stopCustom(token) {
    const run = customRun; ++customEpoch; clearRun(run); customRun = null;
    const tokens = [...new Set([token, ...(run ? [run.token] : []), ...[...customSessions.values()].map(j => j.run.token)])];
    for (const job of customSessions.values()) { clearTimeout(job.s.timer); job.s.finish(); }
    customSessions.clear();
    for (const d of active()) if (d.characteristics.includes(UUID.customRX)) {
      (async () => { for (const t of tokens) await write(d, UUID.customRX, [198, 4, t & 255, (t >> 8) & 255]); })().catch(e => status(e.message));
    }
  }
  function notification(id, characteristic, bytes) {
    const b = bytes;
    if (b.length !== 12) return;
    if (characteristic === UUID.collectStatus && collectRun) {
      const run = collectRun, s = run.sessions.get(id);
      if (!s || run.failed || b[0] !== 197 || word(b, 2) !== (run.token & 65535)) return;
      if (b[1] === 4) { collectFail(run); return; }
      const leader = [...run.sessions.keys()].find(key => devices.get(key)?.profile === 'CUSTOM');
      if (b[1] === 3) {
        if (leader === id) call('hsCollectStopped', run.token);
        clearRun(run); collectRun = null; return;
      }
      if (![1,2].includes(b[1]) || word(b, 8) !== s.data.length || word(b, 10) !== s.checksum || b[7] !== run.target) return;
      collectAccept(run, s);
      if (leader === id) call('hsCollectStatus', run.token, b[1], word(b, 4), b[6], run.target, s.data.length);
    }
    if (characteristic === UUID.customStatus && customSessions.has(id)) {
      const {run, s} = customSessions.get(id);
      if (!s || run.failed || b[0] !== 198 || word(b, 2) !== (run.token & 65535)) return;
      if (b[1] === 4) { customFail(run, ({1:10, 2:11, 4:12})[b[4]] || 7); return; }
      if (b[1] === 3) {
        s.finish(); clearTimeout(s.timer); customSessions.delete(id);
        if (customRun === run) { call('hsCustomStatus', run.token, 3, 0, 0, 255, run.count); clearRun(run); customRun = null; }
        return;
      }
      if (![1,2].includes(b[1]) || word(b, 8) !== run.count || word(b, 10) !== run.checksum) return;
      s.accepted = true; s.latest = b; clearTimeout(s.timer); s.finish(); run.pending.delete(id); customReport(run);
      if (s.liveColor) {
        const d = devices.get(id), color = s.liveColor; s.liveColor = null;
        if (d?.ready) write(d, UUID.customRX, [198, 5, run.token & 255, (run.token >> 8) & 255, ...color]).catch(() => customFail(run, 5));
      }
    }
  }
  window.__hsIOSReceive = event => {
    if (event.type === 'reply') {
      const req = requests.get(event.id); if (!req) return;
      clearTimeout(req.timeout); requests.delete(event.id);
      event.error ? req.reject(Error(event.error)) : req.resolve(event.value); return;
    }
    if (event.type === 'status') { detected = event.detected; status(event.text); }
    if (event.type === 'ready') {
      const profile = P.classify(event.name, event.custom);
      devices.set(event.device, {id:event.device, name:event.name, ready:true,
        profile:profile === 'UNKNOWN' ? 'B_COMPACT' : profile, characteristics:event.characteristics}); summary();
    }
    if (event.type === 'disconnected') {
      const d = devices.get(event.device); if (d) d.ready = false;
      if (collectRun?.sessions.has(event.device)) collectFail(collectRun);
      if (customSessions.has(event.device)) { const job = customSessions.get(event.device); customFail(job.run, 3); customSessions.delete(event.device); }
      if (customRun?.sessions.has(event.device)) customFail(customRun, 3);
      summary();
    }
    if (event.type === 'notification') notification(event.device, event.characteristic, event.bytes);
  };
  window.HsNative = Object.freeze({
    connect() { rpc('connect').catch(e => status(e.message)); },
    disconnect() {
      cancelCollect(); ++customEpoch; clearRun(customRun); customRun = null;
      for (const job of customSessions.values()) { clearTimeout(job.s.timer); job.s.finish(); } customSessions.clear();
      rpc('disconnect').catch(e => status(e.message));
    },
    send:(cmd, value, channel) => basic('simple', cmd, value, channel),
    rgb:(r, g, b, channel) => basic('rgb', r, g, b, channel),
    pixel:count => basic('pixel', count), remSetting:(cmd, value) => basic('rem', cmd, value),
    subareaDouble(area) {
      for (const d of active()) if (d.profile === 'CUSTOM') {
        const packet = P.simple(d.profile, 20, area, 3);
        write(d, UUID.tx, packet).catch(e => status(e.message));
        setTimeout(() => { if (d.ready) write(d, UUID.tx, packet).catch(e => status(e.message)); }, 160);
      }
    },
    collectSend:collectStart, collectCancel:cancelCollect,
    modePreview(mode, target) {
      if (!Number.isInteger(mode) || mode < 1 || mode > 210 || target < 1 || target > 5) return;
      for (const d of active()) {
        const custom = d.profile === 'CUSTOM', packet = P.simple(d.profile, custom ? 30 : 3, mode, custom ? target : 3);
        if (packet) write(d, UUID.tx, packet).catch(e => status(e.message));
      }
    },
    customSend:(text, token) => customStart(text, token, false),
    customPreview:(text, token) => customStart(text, token, true), customStop:stopCustom,
    customColor(token, r, g, b) {
      const run = customRun;
      if (!run || run.token !== token || run.failed || ![r,g,b].every(v => Number.isInteger(v) && v >= 0 && v <= 255)) return;
      for (const s of run.sessions.values()) {
        if (!s.accepted) { s.liveColor = [r,g,b]; continue; }
        const d = devices.get(s.id); if (d?.ready) write(d, UUID.customRX, [198, 5, token & 255, (token >> 8) & 255, r, g, b]).catch(() => customFail(run, 5));
      }
    },
    ota() { rpc('ota').catch(e => status(e.message)); },
    exit() { rpc('exit').catch(e => status(e.message)); }
  });
  // Auto-connect timing matches Android onPageFinished, after all original scripts load.
  window.addEventListener('load', () => setTimeout(() => { status(); window.HsNative.connect(); }, 550), {once:true});
})();
