import Foundation
import CoreBluetooth

// All state and delegate callbacks run on the main queue.
final class BluetoothTransport: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    private static let controlService = CBUUID(string: "FFE0")
    private static let controlTX = CBUUID(string: "FFE1")
    private static let otaService = CBUUID(string: "7E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    private struct Write {
        let request: Int
        let characteristic: CBCharacteristic
        let data: Data
        let deadline: Date
    }
    private final class Connection {
        let peripheral: CBPeripheral
        let name: String
        var custom: Bool
        var characteristics: [String: CBCharacteristic] = [:]
        var pendingServices = Set<CBUUID>()
        var subscribers: [String: [Int]] = [:]
        var queue: [Write] = []
        var writing: Write?
        var coolingDown = false
        var ready = false
        init(_ peripheral: CBPeripheral, name: String, custom: Bool) {
            self.peripheral = peripheral; self.name = name; self.custom = custom
        }
    }
    var event: (([String: Any]) -> Void)?
    private var central: CBCentralManager?
    private var pendingScan = false
    private var scanning = false
    private var scanEpoch = 0
    private var found = Set<UUID>()
    private var connections: [UUID: Connection] = [:]

    func connect() {
        pendingScan = true
        if central == nil { central = CBCentralManager(delegate: self, queue: .main) }
        else { beginScanIfPossible() }
    }
    private func status(_ text: String) {
        event?(["type": "status", "text": text, "detected": max(found.count, connections.values.filter { $0.ready }.count)])
    }
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn: beginScanIfPossible()
        case .unauthorized: status("Izinkan Bluetooth untuk HS JAYA di Pengaturan iPhone")
        case .poweredOff: status("Aktifkan Bluetooth, lalu tekan Scan Ulang")
        case .unsupported: status("Bluetooth tidak tersedia")
        case .resetting: status("Bluetooth sedang dimulai ulang")
        default: status("Menyiapkan Bluetooth…")
        }
        if central.state != .poweredOn {
            scanning = false; scanEpoch += 1
            for c in Array(connections.values) { remove(c, reason: "Bluetooth tidak tersedia") }
        }
    }
    private func beginScanIfPossible() {
        guard pendingScan, !scanning, let central = central, central.state == .poweredOn else { return }
        pendingScan = false; scanning = true; found.removeAll(); scanEpoch += 1
        let epoch = scanEpoch
        status("Mencari & menghubungkan perangkat otomatis…")
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.2) { [weak self] in
            guard let self = self, self.scanEpoch == epoch, self.scanning else { return }
            self.central?.stopScan(); self.scanning = false
            let ready = self.connections.values.filter { $0.ready }.count
            self.status(ready > 0 ? "\(max(self.found.count, ready)) perangkat terdeteksi · \(ready) terhubung" : self.found.isEmpty ? "Modul LED belum ditemukan · cek daya atau koneksi aplikasi lama" : "\(self.found.count) perangkat terdeteksi · menghubungkan otomatis…")
        }
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? peripheral.name ?? ""
        let upper = name.uppercased()
        let advertised = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] ?? []
        let custom = advertised.contains(Self.otaService) || ["RGB HYBRID", "HS JAYA", "HS-JAYA"].contains { upper.contains($0) }
        guard upper.hasPrefix("LED") || custom || advertised.contains(Self.controlService) else { return }
        guard !found.contains(peripheral.identifier) else { return }
        found.insert(peripheral.identifier)
        guard connections[peripheral.identifier] == nil else { return }
        let epoch = scanEpoch
        let delay = min(3.5, Double(max(0, found.count - 1)) * 0.22)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self = self, self.scanEpoch == epoch, self.connections[peripheral.identifier] == nil else { return }
            let c = Connection(peripheral, name: name, custom: custom)
            self.connections[peripheral.identifier] = c; peripheral.delegate = self
            central.connect(peripheral, options: nil)
            self.status("\(self.found.count) perangkat terdeteksi · menghubungkan otomatis…")
            DispatchQueue.main.asyncAfter(deadline: .now() + 14) { [weak self, weak c] in
                guard let self = self, let c = c, self.connections[peripheral.identifier] === c, !c.ready else { return }
                self.remove(c, reason: "Koneksi Bluetooth timeout"); central.cancelPeripheralConnection(peripheral)
            }
        }
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        guard connections[peripheral.identifier] != nil else { central.cancelPeripheralConnection(peripheral); return }
        peripheral.discoverServices(nil)
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        if let c = connections[peripheral.identifier] { remove(c, reason: error?.localizedDescription ?? "Gagal terhubung") }
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if let c = connections[peripheral.identifier] { remove(c, reason: error?.localizedDescription ?? "Koneksi terputus") }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let c = connections[peripheral.identifier] else { return }
        guard error == nil, let services = peripheral.services, services.contains(where: { $0.uuid == Self.controlService }) else {
            remove(c, reason: "Layanan LED tidak tersedia"); central?.cancelPeripheralConnection(peripheral); return
        }
        c.custom = c.custom || services.contains { $0.uuid == Self.otaService }
        let relevant = services.filter { s in
            s.uuid == Self.controlService || s.uuid == CBUUID(string: "7DB10000-7E68-4E55-A8D3-B8096B25B5A0") || s.uuid == CBUUID(string: "7DB20000-7E68-4E55-A8D3-B8096B25B5A0")
        }
        c.pendingServices = Set(relevant.map { $0.uuid })
        for service in relevant { peripheral.discoverCharacteristics(nil, for: service) }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let c = connections[peripheral.identifier] else { return }
        guard error == nil else { remove(c, reason: "Pembacaan layanan gagal"); central?.cancelPeripheralConnection(peripheral); return }
        for characteristic in service.characteristics ?? [] { c.characteristics[characteristic.uuid.uuidString.uppercased()] = characteristic }
        c.pendingServices.remove(service.uuid)
        guard c.pendingServices.isEmpty, !c.ready else { return }
        guard let tx = c.characteristics[Self.controlTX.uuidString], tx.properties.contains(.write) || tx.properties.contains(.writeWithoutResponse) else {
            remove(c, reason: "Kanal kirim LED tidak tersedia"); central?.cancelPeripheralConnection(peripheral); return
        }
        c.ready = true
        event?(["type": "ready", "device": peripheral.identifier.uuidString, "name": c.name, "custom": c.custom, "characteristics": c.characteristics.keys.sorted()])
    }
    private func reply(_ id: Int, error: String? = nil) {
        var value: [String: Any] = ["type": "reply", "id": id]
        if let error = error { value["error"] = error }
        event?(value)
    }
    func subscribe(device: String, characteristic: String, request: Int) {
        guard let id = UUID(uuidString: device), let c = connections[id], c.ready,
              let ch = c.characteristics[CBUUID(string: characteristic).uuidString.uppercased()],
              ch.properties.contains(.notify) || ch.properties.contains(.indicate) else {
            reply(request, error: "Layanan notifikasi tidak tersedia"); return
        }
        if ch.isNotifying { reply(request); return }
        let key = ch.uuid.uuidString.uppercased()
        let waiting = c.subscribers[key] != nil
        c.subscribers[key, default: []].append(request)
        if !waiting { c.peripheral.setNotifyValue(true, for: ch) }
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self, weak c] in
            guard let self = self, let c = c, c.subscribers[key]?.contains(request) == true else { return }
            c.subscribers[key]?.removeAll { $0 == request }
            if c.subscribers[key]?.isEmpty == true { c.subscribers.removeValue(forKey: key) }
            self.reply(request, error: "Notifikasi Bluetooth timeout")
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard let c = connections[peripheral.identifier] else { return }
        let ids = c.subscribers.removeValue(forKey: characteristic.uuid.uuidString.uppercased()) ?? []
        for id in ids { reply(id, error: error?.localizedDescription ?? (characteristic.isNotifying ? nil : "Notifikasi gagal")) }
    }
    func write(device: String, characteristic: String, bytes: [Int], request: Int) {
        guard let id = UUID(uuidString: device), let c = connections[id], c.ready,
              let ch = c.characteristics[CBUUID(string: characteristic).uuidString.uppercased()] else {
            reply(request, error: "Perangkat/layanan tidak terhubung"); return
        }
        guard !bytes.isEmpty, bytes.allSatisfy({ (0...255).contains($0) }), c.queue.count < 128 else {
            reply(request, error: "Paket tidak valid atau antrean penuh"); return
        }
        let withResponse = ch.properties.contains(.write)
        guard withResponse || (ch.uuid == Self.controlTX && ch.properties.contains(.writeWithoutResponse)) else {
            reply(request, error: "Layanan tidak mendukung penulisan yang diperlukan"); return
        }
        let type: CBCharacteristicWriteType = withResponse ? .withResponse : .withoutResponse
        guard bytes.count <= c.peripheral.maximumWriteValueLength(for: type) else {
            reply(request, error: "Paket melebihi kapasitas Bluetooth"); return
        }
        c.queue.append(Write(request: request, characteristic: ch, data: Data(bytes.map { UInt8($0) }), deadline: Date().addingTimeInterval(10)))
        drain(c)
    }
    private func drain(_ c: Connection) {
        guard connections[c.peripheral.identifier] === c, c.ready, c.writing == nil, !c.coolingDown, let next = c.queue.first else { return }
        if next.deadline < Date() {
            c.queue.removeFirst(); reply(next.request, error: "Antrean Bluetooth timeout"); drain(c); return
        }
        let type: CBCharacteristicWriteType = next.characteristic.properties.contains(.write) ? .withResponse : .withoutResponse
        if type == .withoutResponse && !c.peripheral.canSendWriteWithoutResponse { return }
        c.queue.removeFirst(); c.writing = next
        c.peripheral.writeValue(next.data, for: next.characteristic, type: type)
        if type == .withoutResponse { finishWrite(c, error: nil) }
        else {
            DispatchQueue.main.asyncAfter(deadline: .now() + max(0, next.deadline.timeIntervalSinceNow)) { [weak self, weak c] in
                guard let self = self, let c = c, c.writing?.request == next.request else { return }
                self.remove(c, reason: "Kirim Bluetooth timeout"); self.central?.cancelPeripheralConnection(c.peripheral)
            }
        }
    }
    private func finishWrite(_ c: Connection, error: Error?) {
        guard let item = c.writing else { return }
        c.writing = nil; c.coolingDown = true
        reply(item.request, error: error?.localizedDescription)
        let delay = item.characteristic.uuid == Self.controlTX ? 0.065 : 0.0
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self, weak c] in
            guard let self = self, let c = c else { return }
            c.coolingDown = false; self.drain(c)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let c = connections[peripheral.identifier], c.writing?.characteristic.uuid == characteristic.uuid else { return }
        finishWrite(c, error: error)
    }
    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        if let c = connections[peripheral.identifier] { drain(c) }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil, let data = characteristic.value, connections[peripheral.identifier]?.ready == true else { return }
        event?(["type": "notification", "device": peripheral.identifier.uuidString, "characteristic": characteristic.uuid.uuidString.uppercased(), "bytes": Array(data)])
    }
    private func remove(_ c: Connection, reason: String) {
        guard connections[c.peripheral.identifier] === c else { return }
        connections.removeValue(forKey: c.peripheral.identifier); c.ready = false
        if let write = c.writing { reply(write.request, error: reason) }; c.writing = nil
        for write in c.queue { reply(write.request, error: reason) }; c.queue.removeAll()
        for ids in c.subscribers.values { for id in ids { reply(id, error: reason) } }; c.subscribers.removeAll()
        event?(["type": "disconnected", "device": c.peripheral.identifier.uuidString])
    }
    func disconnect() {
        pendingScan = false; scanEpoch += 1; scanning = false; central?.stopScan()
        for c in Array(connections.values) { remove(c, reason: "Koneksi diputus"); central?.cancelPeripheralConnection(c.peripheral) }
        found.removeAll(); status("Belum terhubung")
    }
}
