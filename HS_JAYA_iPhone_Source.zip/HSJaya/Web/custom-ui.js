(function(){let cleanup=null,serial=0;window.HsCustom={unmount(){cleanup?.();cleanup=null},mount(root,host={}){this.unmount();root.innerHTML=window.HsCustomTemplate;
'use strict';
const E=HsCustomEngine,$=id=>root.querySelector('#'+id),KEY='hsjaya_custom_circle_v2',GLOBAL_KEY='hsjaya_custom_circle_globals_v2';
let globalSettings={speed:75,brightness:50};
try{const saved=JSON.parse(localStorage.getItem(GLOBAL_KEY));if(saved&&typeof saved==='object'){const value=E.normalize(saved);globalSettings={speed:value.speed,brightness:value.brightness}}}catch(_){}
const shared=host.globals?.();if(shared)globalSettings={speed:shared.speed,brightness:shared.brightness};
let config=E.normalize({area:shared?.pixel||75,head:5,tail:8,...globalSettings,duration:5,mode:50,color:'#ff5500',channel:'ALL'}),selected=0,slots=Array(10).fill(null),playing=false,sequence=false,runningSlot=-1,tick=0,last=0,slotStart=0;
try{const data=JSON.parse(localStorage.getItem(KEY));if(Array.isArray(data))slots=Array.from({length:10},(_,i)=>data[i]?E.normalize(data[i]):null)}catch(_){}
// Preserve old saved presets when upgrading the isolated CUSTOM page.
if(!localStorage.getItem(KEY)){try{const old=JSON.parse(localStorage.getItem('hsjaya_custom_compact_v1'));if(old?.slots)slots=Array.from({length:10},(_,i)=>old.slots[i]?E.normalize(old.slots[i]):null)}catch(_){}}
const DRAFT_KEY='hsjaya_custom_live_draft_v1';try{const saved=JSON.parse(localStorage.getItem(DRAFT_KEY));if(saved&&typeof saved==='object')config=E.normalize({...saved,...globalSettings,area:shared?.pixel||saved.area});}catch(_){}
function saveDraft(){try{localStorage.setItem(DRAFT_KEY,JSON.stringify(config))}catch(_){}}
let alive=true,raf=0,hardware=false,pending=false,token=0,payload=[],globalTimer=null,colorTimer=null,previewTimer=null,transient=false,draftRevision=0,sentRevision=0,lastPixelSent=null,lastGlobals={},lastPayload='';
const native=()=>window.HsNative;
const status=s=>$('presetStatus').textContent=s;
const sharedConfig=p=>E.normalize({...p,...globalSettings,area:host.globals?.().pixel||config.area});
function sendGlobals(){for(const k of ['speed','brightness'])if(lastGlobals[k]!==globalSettings[k]){host.setGlobal?.(k,globalSettings[k]);lastGlobals[k]=globalSettings[k];}}
function commitPixel(){if(readFields()&&lastPixelSent!==config.area){host.setPixel?.(config.area);lastPixelSent=config.area;}}
function sendColor(){colorTimer=null;if((hardware||pending)&&native()?.customColor){const rgb=config.color.slice(1).match(/../g).map(v=>parseInt(v,16));native().customColor(token,...rgb)}}
function startHardware(all,slotIndex,preview=false){
 const api=native();if(!api)return;
 if(preview&&!api.customPreview){status('CUSTOM: APK belum mendukung preview langsung.');return;}
 if(!preview&&!api.customSend)return;
 commitPixel();sendGlobals();payload=all?slots.map((s,i)=>s?{...sharedConfig(s),slot:i}:null).filter(Boolean):[{...sharedConfig(config),slot:slotIndex<0?255:slotIndex}];
 const json=JSON.stringify(payload);if(preview&&transient&&(hardware||pending)&&json===lastPayload){sentRevision=draftRevision;return;}
 lastPayload=json;token=(Date.now()+ ++serial)&65535;pending=true;transient=preview;sentRevision=draftRevision;
 $('playState').textContent='Mengirim ke modul…';status('Menunggu verifikasi firmware CUSTOM.');
 api[preview?'customPreview':'customSend'](json,token);
}
function queuePreview(delay=80){
 draftRevision++;sequence=false;runningSlot=-1;last=slotStart=performance.now();playing=true;$('playState').textContent='Preview · live';saveDraft();renderSlots();draw();
 if(previewTimer!==null)return;
 previewTimer=setTimeout(()=>{previewTimer=null;if(!alive||!readFields())return;startHardware(false,-1,true)},delay);
}
const failures={1:'CUSTOM: belum ada modul terhubung.',2:'CUSTOM: service tidak ditemukan. Sambungkan ulang setelah flash firmware CUSTOM.',3:'CUSTOM: koneksi service terputus / discovery gagal.',4:'CUSTOM: notifikasi service tidak dapat diaktifkan.',5:'CUSTOM: paket gagal ditulis ke modul.',6:'CUSTOM: modul tidak memberi verifikasi (timeout).',7:'CUSTOM: firmware menolak paket.',8:'CUSTOM: konfigurasi tidak valid.',10:'CUSTOM: modul sedang terkunci.',11:'CUSTOM: input SENJA belum aktif.',12:'CUSTOM: firmware belum mendukung preview langsung.'};
window.hsCustomStatus=(t,event,index,mode,slot,count)=>{
 if(!alive||t!==token||(!pending&&!hardware)||sentRevision!==draftRevision||previewTimer)return;
 if(event===1||event===2){const p=payload[index];if(!p||p.mode!==mode||payload.length!==count)return;pending=false;hardware=true;if(!transient){config=sharedConfig(p);runningSlot=slot<10?slot:-1;if(slot<10)selected=slot;syncFields();if(event===2)tick=0;}slotStart=last=performance.now();playing=true;renderSlots();draw();$('playState').textContent=transient?'Modul · live':slot<10?'Modul · slot '+(slot+1):'Modul · berjalan';status('Mode '+mode+' terverifikasi di modul.'+(transient?' Setting terakhir disimpan otomatis.':''));}
 else if(event===3||event===4){pending=hardware=false;status(event===4?(failures[index]||failures[7]):'Modul dihentikan. Preview layar tetap berjalan.');}
};
for(const event of ['click','input','change'])root.addEventListener(event,e=>e.stopPropagation());
for(const event of ['change','blur'])$('area').addEventListener(event,commitPixel);
function saveStorage(){try{localStorage.setItem(KEY,JSON.stringify(slots));return true}catch(_){status('Stockage browser tidak tersedia; preset masih tersimpan di sesi ini.');return false}}
function renderSlots(){
 $('presetGrid').replaceChildren(...slots.map((s,i)=>{const b=document.createElement('button');b.className='slot'+(i===selected?' selected':'')+(i===runningSlot?' running':'');b.setAttribute('aria-label',`Preset ${i+1}, ${s?'mode '+s.mode+', '+s.duration+' detik':'kosong'}`);b.setAttribute('aria-pressed',String(i===selected));b.innerHTML=`<strong>${i+1}</strong><small>${s?'M'+s.mode+' · '+s.duration+'s':'＋'}</small>`;b.onclick=()=>{selected=i;if(slots[i]){start(i);return}renderSlots();status(slots[i]?`Slot ${i+1}: Mode ${slots[i].mode} · ${slots[i].duration} dtk. Muat atau Jalankan.`:`Slot ${i+1} kosong — atur angka, lalu Simpan.`)};return b}));
 $('save').textContent='▣ SIMPAN · '+(selected+1);$('savedCount').textContent=slots.filter(Boolean).length+' / 10 tersimpan';
}
function syncSliders(){for(const k of ['speed','brightness']){$(k).value=globalSettings[k];$(k+'Value').textContent=globalSettings[k]+'%';$(k).style.setProperty('--fill',((globalSettings[k]-1)/99*100)+'%')}}
function syncFields(){for(const id of ['reverse','bounce','tailBack','tailFront'])$(id).checked=config[id];config={...config,...globalSettings};for(const k of ['area','head','tail','duration','color','mode'])$(k).value=config[k];$('colorOpen').style.setProperty('--chosen',config.color);syncSliders();root.querySelectorAll('[data-channel]').forEach(b=>b.classList.toggle('active',b.dataset.channel===config.channel))}
function readFields(){const draft={...config,...globalSettings};for(const k of ['area','head','tail','duration']){const input=$(k);if(input.value===''||!input.validity.valid){status('Periksa angka '+input.labels[0].textContent+' ('+input.min+'–'+input.max+').');return false}draft[k]=Number(input.value)}for(const id of ['reverse','bounce','tailBack','tailFront'])draft[id]=$(id).checked;draft.mode=Number($('mode').value);draft.color=$('color').value;config=E.normalize(draft);return true}
function stop(){clearTimeout(previewTimer);previewTimer=null;draftRevision++;if((hardware||pending)&&native()?.customStop)native().customStop(token);hardware=pending=false;playing=false;sequence=false;runningSlot=-1;$('playState').textContent='Lokal · berhenti';renderSlots()}
function edit(e){const oldMode=config.mode;draftRevision++;if(readFields()){if(config.mode!==oldMode)tick=0;queuePreview(e?.target?.id==='mode'?0:80);status(E.description(config));$('mode').title=E.description(config)}else{clearTimeout(previewTimer);previewTimer=null}}
for(const k of ['area','head','tail','duration','mode'])$(k).addEventListener('input',edit);$('mode').addEventListener('change',edit);
for(const k of ['area','head','tail','duration'])$(k).addEventListener('keydown',e=>{if(e.key==='Enter')e.target.blur()});
for(const k of ['speed','brightness'])$(k).addEventListener('input',()=>{const now=performance.now();if(playing){tick+=(now-last)/E.delay(config);last=now}globalSettings[k]=Number($(k).value);config={...config,...globalSettings};syncSliders();try{localStorage.setItem(GLOBAL_KEY,JSON.stringify(globalSettings))}catch(_){}if(!globalTimer)globalTimer=setTimeout(()=>{globalTimer=null;sendGlobals()},80);draw();status('Speed '+globalSettings.speed+'% · Kecerahan '+globalSettings.brightness+'% — berlaku untuk semua preset.')});
for(const k of ['speed','brightness'])$(k).addEventListener('change',()=>{clearTimeout(globalTimer);globalTimer=null;sendGlobals()});
root.querySelectorAll('[data-channel]').forEach(b=>b.onclick=()=>{config.channel=b.dataset.channel;syncFields();queuePreview()});
$('save').onclick=()=>{if(!readFields())return;commitPixel();slots[selected]={...config};const stored=saveStorage();renderSlots();if(stored)status('Slot '+(selected+1)+' tersimpan di aplikasi.')};

function start(slotIndex=-1,all=false){clearTimeout(previewTimer);previewTimer=null;clearTimeout(colorTimer);colorTimer=null;draftRevision++;hardware=false;if(slotIndex>=0){if(!slots[slotIndex]){status('Slot kosong. Simpan preset terlebih dahulu.');return}config=sharedConfig(slots[slotIndex]);selected=slotIndex;syncFields()}else if(!readFields())return;saveDraft();tick=0;slotStart=performance.now();last=slotStart;playing=true;sequence=all;runningSlot=slotIndex;$('playState').textContent=all?'Lokal · semua preset':slotIndex<0?'Lokal · berjalan':'Lokal · slot '+(slotIndex+1);renderSlots();draw();status(all?'Semua preset tersimpan berjalan berurutan.':'Preview lokal berjalan.');startHardware(all,slotIndex)}
$('runAll').onclick=()=>{const first=slots.findIndex(Boolean);if(first<0){status('Belum ada preset. Atur angka dan Simpan ke salah satu slot.');return}start(first,true)};
for(const id of ['stop'])$(id).onclick=()=>{stop();draw();status('Preview dihentikan.')};
$('remove').onclick=()=>{const removing=selected;if(runningSlot===removing)stop();slots[removing]=null;saveStorage();renderSlots();status('Slot '+(removing+1)+' dihapus.')};
$('back').onclick=()=>{stop();host.back?.()};
const canvas=$('ledCanvas'),ctx=canvas.getContext('2d');let lastFrame=null,hitInfo=null;
function draw(){
 const box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2),w=box.width,h=box.height;if(w<=0||h<=0)return;
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
 const f=E.frame(config,tick),n=f.pixels.length;lastFrame=f;
 const cols=Math.min(n,Math.max(10,Math.ceil(Math.sqrt(n*w/h)))),rows=Math.ceil(n/cols),sx=w/cols,sy=h/rows,r=Math.max(.45,Math.min(sx,sy)*.36);
 hitInfo={cols,sx,sy,n};for(let i=0;i<n;i++){const p=f.pixels[i],x=(i%cols+.5)*sx,y=(Math.floor(i/cols)+.5)*sy;ctx.globalAlpha=p.alpha>0?p.alpha:1;ctx.fillStyle=p.alpha>0?p.color:'#112233';ctx.shadowColor=p.alpha>0?p.color:'transparent';ctx.shadowBlur=p.alpha>0?Math.min(5,r*1.4):0;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}ctx.globalAlpha=1;ctx.shadowBlur=0;
 $('previewInfo').textContent=`${config.channel==='ALL'?'ALL':'LED '+config.channel} · ${n} pixel · blok ${Math.min(config.head,n)} · tail ${Math.min(config.tail,n-Math.min(config.head,n))} · M${config.mode}`;
}
canvas.onclick=e=>{if(!hitInfo)return;const b=canvas.getBoundingClientRect(),i=Math.floor((e.clientY-b.top)/hitInfo.sy)*hitInfo.cols+Math.floor((e.clientX-b.left)/hitInfo.sx);if(i>=0&&i<hitInfo.n)status(`Pixel ${i+1} dari ${hitInfo.n} — total jalur tetap mengikuti Pixel / Chip Setting.`)};
function loop(now){if(!alive)return;if(playing){if(!native()&&sequence&&now-slotStart>=config.duration*1000){let next=runningSlot;for(let j=1;j<=10;j++){const i=(runningSlot+j)%10;if(slots[i]){next=i;break}}config=sharedConfig(slots[next]);runningSlot=next;selected=next;syncFields();tick=0;last=now;slotStart=now;renderSlots();$('playState').textContent='Lokal · semua · slot '+(next+1);status('Semua preset · Slot '+(next+1)+' · Mode '+config.mode);draw()}else if(now-last>=16){tick+=(now-last)/E.delay(config);last=now;draw()}}raf=requestAnimationFrame(loop)}
const canvasResize=new ResizeObserver(draw);canvasResize.observe(canvas.parentElement);syncFields();renderSlots();draw();raf=requestAnimationFrame(loop);
const colorDialog=$('colorDialog'),colorWheel=$('colorWheel'),wheelContext=colorWheel.getContext('2d');let wheelImage=null,wheelPoint=null,colorPointer=null;
function rgbFromHS(h,s){h=((h%360)+360)%360;s=Math.max(0,Math.min(1,s));const f=(o,k=(o+h/60)%6)=>Math.round(255*(1-s*Math.max(0,Math.min(k,4-k,1))));return [f(5),f(3),f(1)]}
function colorInfo(){const rgb=config.color.slice(1).match(/../g).map(v=>parseInt(v,16));$('colorValue').textContent=config.color.toUpperCase()+' · R '+rgb[0]+' / G '+rgb[1]+' / B '+rgb[2];$('colorOpen').style.setProperty('--chosen',config.color)}
function paintWheel(){if(!wheelImage)return;wheelContext.putImageData(wheelImage,0,0);if(wheelPoint){const r=colorWheel.width/2,x=r+wheelPoint.x*r,y=r+wheelPoint.y*r;wheelContext.strokeStyle='#111';wheelContext.lineWidth=3;wheelContext.beginPath();wheelContext.arc(x,y,7,0,2*Math.PI);wheelContext.stroke();wheelContext.strokeStyle='#fff';wheelContext.lineWidth=1.5;wheelContext.stroke()}}
function fitWheel(){if(!colorDialog.open)return;const b=colorWheel.getBoundingClientRect(),size=Math.max(1,Math.round(b.width*Math.min(devicePixelRatio||1,2)));colorWheel.width=colorWheel.height=size;const image=wheelContext.createImageData(size,size),r=size/2;for(let y=0;y<size;y++)for(let x=0;x<size;x++){const dx=(x+.5-r)/r,dy=(y+.5-r)/r,s=Math.hypot(dx,dy),i=(y*size+x)*4;if(s<=1){const rgb=rgbFromHS(Math.atan2(dy,dx)*180/Math.PI,s);image.data[i]=rgb[0];image.data[i+1]=rgb[1];image.data[i+2]=rgb[2];image.data[i+3]=255}}wheelImage=image;paintWheel()}
function chooseColor(value){config={...config,color:value};if(payload.length){const i=sequence?payload.findIndex(p=>p.slot===runningSlot):0;if(i>=0)payload[i]={...payload[i],color:value};}$('color').value=value;colorInfo();draw();saveDraft();playing=true;if(hardware||pending){if(!colorTimer)colorTimer=setTimeout(sendColor,30)}else queuePreview(0);status('Warna '+value.toUpperCase()+' dipilih. Simpan untuk menyimpan ke preset.')}
function pointColor(e){const b=colorWheel.getBoundingClientRect();let x=(e.clientX-b.left-b.width/2)/(b.width/2),y=(e.clientY-b.top-b.height/2)/(b.height/2),s=Math.hypot(x,y);if(s>1){x/=s;y/=s;s=1}wheelPoint={x,y};const rgb=rgbFromHS(Math.atan2(y,x)*180/Math.PI,s);chooseColor('#'+rgb.map(v=>v.toString(16).padStart(2,'0')).join(''));paintWheel()}
$('colorOpen').onclick=()=>{wheelPoint=null;colorDialog.showModal();colorInfo();fitWheel();$('colorClose').focus()};
for(const id of ['colorClose','colorDone'])$(id).onclick=()=>colorDialog.close();
colorDialog.addEventListener('close',()=>{colorPointer=null;wheelPoint=null;$('colorOpen').focus()});
colorDialog.addEventListener('click',e=>{if(e.target===colorDialog){const b=colorDialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)colorDialog.close()}});
colorWheel.onpointerdown=e=>{if(e.button>0)return;e.preventDefault();colorPointer=e.pointerId;colorWheel.setPointerCapture(e.pointerId);pointColor(e)};
colorWheel.onpointermove=e=>{if(colorPointer===e.pointerId){e.preventDefault();pointColor(e)}};
colorWheel.onpointerup=colorWheel.onpointercancel=colorWheel.onlostpointercapture=()=>{colorPointer=null;wheelPoint=null;paintWheel()};
colorWheel.onkeydown=e=>{const moves={ArrowLeft:[-.04,0],ArrowRight:[.04,0],ArrowUp:[0,-.04],ArrowDown:[0,.04]};if(!moves[e.key])return;e.preventDefault();const p=wheelPoint||{x:0,y:0},v=moves[e.key],b=colorWheel.getBoundingClientRect();pointColor({clientX:b.left+b.width/2+(p.x+v[0])*b.width/2,clientY:b.top+b.height/2+(p.y+v[1])*b.height/2})};
root.querySelectorAll('[data-color]').forEach(b=>b.onclick=()=>{wheelPoint=null;chooseColor(b.dataset.color);paintWheel()});
const wheelResize=new ResizeObserver(fitWheel);wheelResize.observe(colorWheel.parentElement);
window.HsNumericPreview={engine:E,get config(){return {...config}},get slots(){return slots.map(s=>s?{...s}:null)},get runningSlot(){return runningSlot},get playing(){return playing},get frame(){return lastFrame}};

for(const id of ['reverse','bounce','tailBack','tailFront'])$(id).addEventListener('change',()=>{if(readFields()){tick=0;queuePreview(0)}});

queuePreview(0);
cleanup=()=>{if(!alive)return;stop();alive=false;cancelAnimationFrame(raf);clearTimeout(globalTimer);clearTimeout(colorTimer);clearTimeout(previewTimer);canvasResize.disconnect();wheelResize.disconnect();if(colorDialog.open)colorDialog.close();delete window.hsCustomStatus;delete window.HsNumericPreview;};

}};})();
