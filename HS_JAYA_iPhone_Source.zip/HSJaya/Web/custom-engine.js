/* LOCAL HTML PROPOSAL ONLY. No BLE, no firmware/Mode 210 engine changes. */
(function(scope){
 'use strict';
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,Math.round(Number(v)||0)));
 const normalize=p=>({channel:['ALL','1','2','3','4'].includes(p?.channel)?p.channel:'ALL',area:clamp(p?.area??75,1,1000),head:clamp(p?.head??5,1,1000),tail:clamp(p?.tail??8,0,1000),speed:clamp(p?.speed??75,1,100),brightness:clamp(p?.brightness??50,1,100),duration:clamp(p?.duration??5,1,60),mode:clamp(p?.mode??50,1,50),color:/^#[\da-f]{6}$/i.test(p?.color)?p.color:'#ff5500',reverse:p?.reverse===true,bounce:p?.bounce===true,tailBack:p?.tailBack!==false,tailFront:p?.tailFront===true});
 const mod=(v,n)=>((v%n)+n)%n;
 const hash=k=>{let x=(Math.imul(Math.floor(k)+1,374761393)+668265263)>>>0;x=Math.imul(x^(x>>>13),1274126177)>>>0;return ((x^(x>>>16))>>>0)/4294967296;};
 const rainbow=h=>{h=mod(h,360);const f=(n,k=(n+h/60)%6)=>Math.round(255-255*Math.max(Math.min(k,4-k,1),0));return `rgb(${f(5)},${f(3)},${f(1)})`;};
 const descriptions=[
  'Blok utuh melaju dari kiri ke kanan; ulang dari ujung.',
  'Blok utuh melaju dari kanan ke kiri; ulang dari ujung.',
  'Blok bolak-balik dengan kecepatan gerak tetap.',
  'Dua blok berangkat dari tengah, menjauh ke kedua ujung.',
  'Dua blok dari ujung bertemu di tengah, lalu ulang.',
  'Dua gelombang keluar bertahap, berhenti sebentar di ujung.',
  'Dua meteor bertemu; cahaya tengah berdenyut lalu padam.',
  'Satu blok mengejar dengan ritme nyala–jeda.',
  'Dua blok berjarak tetap berputar sepanjang jalur.',
  'Tiga blok berjarak tetap mengejar sepanjang jalur.',
  'Comet: kepala terang, ekor pendek lembut.',
  'Comet: kepala terang, ekor panjang mengalir.',
  'Meteor mempercepat gerak; ekor meluruh bertahap.',
  'Meteor menyapu, kemudian ekornya habis sebelum ulang.',
  'Scanner menyapu dengan perlambatan halus di ujung.',
  'Dua scanner menyapu separuh jalur, saling berlawanan.',
  'Scanner dengan ekor yang mengikuti arah gerakan.',
  'Knight Rider: sapuan cepat dengan jeda di kedua ujung.',
  'Wipe mengisi jalur dari kiri, lalu mulai lagi.',
  'Wipe mengisi jalur dari kanan, lalu mulai lagi.',
  'Wipe mengisi lalu mengosongkan jalur secara berbalik.',
  'Isi, tahan penuh, kosongkan bertahap, tahan gelap.',
  'Pengisian melebar dari tengah menuju dua ujung.',
  'Pengisian dari kedua ujung menuju tengah.',
  'Running block menyambung melewati batas ujung jalur.',
  'Running block cepat dengan jeda antar sapuan.',
  'Paket blok masuk dan menumpuk diam hingga jalur penuh.',
  'Random dot: titik pindah secara acak, tanpa ekor.',
  'Random position: satu blok utuh berpindah tempat.',
  'Sparkle: kilau singkat di titik-titik acak.',
  'Twinkle: bintang menyala–redup bergantian secara halus.',
  'Strobe satu blok tetap; seluruh blok berkedip bersama.',
  'Strobe blok bergantian di ujung kiri dan kanan.',
  'Strobe blok acak dengan kedipan ganda.',
  'Random flash: satu blok bersinar lalu memudar.',
  'Group flash: blok berpindah per kelompok sepanjang jalur.',
  'Blok maju sambil berdenyut terang–redup.',
  'Blok mundur sambil berdenyut cepat.',
  'Blok bolak-balik berdenyut di setiap sapuan.',
  'Breathing: blok dan ekor mengalir sambil bernapas perlahan.',
  'Fade trail: ekor meluruh tajam di belakang kepala.',
  'Long tail: sapuan panjang dengan ekor lembut.',
  'Short tail: gerak mundur dengan ekor pendek.',
  'Seluruh jalur pelangi bergeser tanpa area gelap.',
  'Comet pelangi dengan warna kepala yang terus berubah.',
  'Blok mengisi jalur bertahap: merah → hijau → biru.',
  'Kelompok blok RGB berganti warna secara bergiliran.',
  'Blok bolak-balik, berganti warna acak saat sampai ujung.',
  'Blok berjalan menyeberangi jalur CH1 lalu CH2.',
  'Blok CH1 → CH2, berbalik lalu kembali melalui CH2 → CH1.'
 ];
 function frame(config,time){
  const c=normalize(config),n=c.area,h=Math.min(c.head,n),tail=Math.min(c.tail,n-h),m=c.mode;
  const rawTime=Math.max(0,Number(time)||0),phase=directionPhase(m,n,h,tail,rawTime,c.bounce),t=phase.time,pixels=Array.from({length:n},()=>({color:'#06101b',alpha:0,head:false}));
  const put=(i,a=1,col=c.color,head=true)=>{if(i<0||i>=n||a<=0)return;i=Math.floor(i);a=Math.min(1,a);const p=pixels[i];if(a>=p.alpha){p.color=col;p.alpha=a;p.head=head;}};
  // Fractional coverage keeps a full contiguous block moving smoothly between pixels.
  const span=(start,len=h,a=1,col=c.color,head=true,wrap=false)=>{
   const end=start+len;
   for(let i=Math.floor(start);i<Math.ceil(end);i++){
    const coverage=Math.max(0,Math.min(i+1,end)-Math.max(i,start));
    put(wrap?mod(i,n):i,a*coverage,col,head);
   }
  };
  const block=(start,dir=1,trail=0,a=1,col=c.color,wrap=false,curve=1)=>{
   dir*=phase.dir;
   for(let k=trail;k>=1;k--){const fade=a*Math.pow(1-k/(trail+1),curve);if(c.tailBack)span(dir>0?start-k:start+h-1+k,1,fade,col,false,wrap);if(c.tailFront)span(dir>0?start+h-1+k:start-k,1,fade,col,false,wrap)}
   span(start,h,a,col,true,wrap);
  };
  const scan=(u,range=n-h)=>{if(range<=0)return {x:0,dir:1};const q=mod(u,2*range);return {x:q<=range?q:2*range-q,dir:q<=range?1:-1};};
  const scattered=seed=>{const list=Array.from({length:n},(_,i)=>i);for(let i=n-1;i>0;i--){const j=Math.floor(hash(seed+i)*(i+1));[list[i],list[j]]=[list[j],list[i]]}return list.slice(0,h)};
  const eased=(u,range=n-h)=>{if(range<=0)return {x:0,dir:1};const phase=mod(u,2*range)/range;return {x:range*(.5-.5*Math.cos(phase*Math.PI)),dir:phase<1?1:-1};};
  const gap=n+h,travel=Math.max(1,n-h),cycle=n+Math.max(8,tail),move=mod(t,travel+1),b=scan(t);
  const pairs=(dist,outward,trail=tail,amp=1)=>{
   const half=(n-h)/2,x=Math.min(half,Math.max(0,dist));
   block(outward?half-x:x,outward?-1:1,trail,amp);
   block(outward?half+x:n-h-x,outward?1:-1,trail,amp);
  };
  switch(m){
   case 1:block(move,1,tail);break;
   case 2:block(n-h-move,-1,tail);break;
   case 3:block(b.x,b.dir,tail);break;
   case 4:pairs(mod(t,travel/2+1),true);break;
   case 5:pairs(mod(t,travel/2+1),false);break;
   case 6:{const half=travel/2,q=mod(t,half+10);pairs(Math.min(half,Math.floor(q/2)*2),true,Math.min(tail,4),q>half?Math.max(.15,1-(q-half)/10):1);break;}
   case 7:{const half=travel/2,q=mod(t,half+16);if(q<=half)pairs(q,false,tail);else span((n-h)/2,h,Math.pow(Math.sin((q-half)*Math.PI/16),2));break;}
   case 8:{const q=mod(t,gap);if(mod(Math.floor(q/4),2)===0)block(q-h,1,tail);break;}
   case 9:for(let k=0;k<2;k++)block(mod(t+k*n/2,n),1,tail,1,c.color,true);break;
   case 10:for(let k=0;k<3;k++)block(mod(t+k*n/3,n),1,tail,1,c.color,true);break;
   case 11:block(mod(t,cycle)-h,1,tail);break;
   case 12:block(mod(t*.85,cycle)-h,1,tail);break;
   case 13:{const q=mod(t,cycle)/cycle;block(q*q*(n+h+tail)-h,1,tail,1,c.color,false,2);break;}
   case 14:{const q=mod(t,cycle+h);block(q-h,1,tail,Math.max(0,1-Math.max(0,q-n)/(h+tail||1)),c.color,false,.6);break;}
   case 15:{const s=eased(t);block(s.x,s.dir,tail);break;}
   case 16:{const range=(n-h)/2,s=eased(t,range);block(s.x,s.dir,Math.min(tail,3));block(n-h-s.x,-s.dir,Math.min(tail,3));break;}
   case 17:{const s=eased(t*.8);block(s.x,s.dir,tail,1,c.color,false,1.5);break;}
   case 18:{const hold=8,q=mod(t*1.6,2*(travel+hold));const rev=q>=travel+hold,x=rev?travel-Math.min(travel,q-travel-hold):Math.min(travel,q);block(x,rev?-1:1,tail);break;}
   case 19:span(0,Math.min(n,mod(t,n+8)));break;
   case 20:{const count=Math.min(n,mod(t,n+10));span(n-count,count);break;}
   case 21:{const count=scan(t,n).x;span(0,count);break;}
   case 22:{const q=mod(t,2*n+24);if(q<n)span(0,q);else if(q<n+12)span(0,n);else if(q<2*n+12){const erase=q-n-12;span(erase,n-erase)}break;}
   case 23:{const count=Math.min(n,mod(t*2,n+12));span((n-count)/2,count);break;}
   case 24:{const count=Math.min(n/2,mod(t,n/2+12));span(0,count);span(n-count,count);break;}
   case 25:block(mod(t,n),1,tail,1,c.color,true);break;
   case 26:{const q=mod(t*2,gap+10);block(q-h,1,tail);break;}
   case 27:{
    // Packets stop against the existing stack; then the complete stack fades.
    const groups=Math.ceil(n/h);let q=t,sum=0,found=false;
    for(let k=0;k<groups;k++){const distance=Math.max(0,n-(k+1)*h),leg=distance+h+2;if(q<sum+leg){const local=q-sum,existing=Math.min(n,k*h);span(n-existing,existing);span(Math.min(distance,local-h),Math.min(h,n-existing));found=true;break}sum+=leg;}
    if(!found){const total=sum+16,phase=mod(t,total);if(t>=total)return frame(c,phase);span(0,n,Math.max(0,1-(t-sum)/16))}break;
   }
   case 28:{const epoch=Math.floor(t/5);for(const i of scattered(epoch*3001))put(i);break;}
   case 29:{const epoch=Math.floor(t/9);span(Math.floor(hash(epoch*37+29)*(n-h+1)));break;}
   case 30:{const epoch=Math.floor(t/6),age=mod(t,6),a=Math.pow(1-age/6,3);for(const i of scattered(epoch*101))put(i,a);break;}
   case 31:{const epoch=Math.floor(t/20),phase=mod(t,20)/20,list=scattered(epoch*503);for(let k=0;k<h;k++){const a=Math.pow(Math.sin(Math.PI*mod(phase+k/h,1)),2);put(list[k],a)}break;}
   // Strobe/flash modes use one contiguous h-pixel block, never random dots.
   case 32:if(mod(Math.floor(t/4),2)===0)span(Math.floor((n-h)/2));break;
   case 33:span(mod(Math.floor(t/5),2)===0?0:n-h);break;
   case 34:{const q=mod(t,16);if(q<2||(q>=4&&q<6))span(Math.floor(hash(Math.floor(t/16)*17+34)*(n-h+1)));break;}
   case 35:{const epoch=Math.floor(t/14),q=mod(t,14);if(q<10)span(Math.floor(hash(epoch*11+35)*(n-h+1)),h,Math.pow(1-q/10,2));break;}
   case 36:{const group=Math.floor(t/8),q=mod(t,8);if(q<4)span(Math.min(n-h,mod(group,Math.ceil(n/h))*h));break;}
   case 37:block(move,1,tail,.15+.85*Math.pow(.5+.5*Math.sin(t*.35),2));break;
   case 38:block(n-h-move,-1,Math.min(tail,5),.1+.9*Math.pow(.5+.5*Math.sin(t*.7),3));break;
   case 39:block(b.x,b.dir,tail,.2+.8*Math.pow(Math.sin(Math.PI*(mod(t,travel+1)/(travel+1))),2));break;
   case 40:{const s=eased(t*.5);block(s.x,s.dir,tail,.05+.95*Math.pow(.5-.5*Math.cos(t*.08),1.5),c.color,false,.5);break;}
   case 41:block(mod(t,n+h+tail)-h,1,tail,1,c.color,false,3);break;
   case 42:block(mod(t*.65,n+h+tail)-h,1,tail,1,c.color,false,.4);break;
   case 43:block(n-mod(t*1.3,n+h+4),-1,Math.min(tail,3));break;
   case 44:for(let i=0;i<n;i++)put(i,1,rainbow(i*360/n-t*6));break;
   case 45:block(mod(t,n+h+tail)-h,1,tail,1,rainbow(t*7));break;
   case 46:{const epoch=Math.floor(t/(n+8)),count=Math.min(n,mod(t,n+8)),colors=['#ff0000','#00ff00','#0000ff'];span(0,count,1,colors[mod(epoch,3)]);break;}
   case 47:{const colors=['#ff0000','#00ff00','#0000ff'],epoch=Math.floor(t/6);for(let i=0;i<n;i++)put(i,1,colors[mod(Math.floor(i/h)+epoch,3)]);break;}
   case 48:{const epoch=Math.floor(t/travel),s=scan(t),col=rainbow(Math.floor(hash(epoch*19+48)*360));block(s.x,s.dir,tail,1,col);break;}
   case 49:block(mod(t,n),1,tail,1,c.color,true);break;
   case 50:block(b.x,b.dir,tail);break;
  }
  const paired=m>=49&&['ALL','1','2'].includes(c.channel);
  // Same 1–100 to 1–255 brightness conversion as the global firmware control.
  const gain=(1+Math.floor(((c.brightness-1)*254+49)/99))/255;
  pixels.forEach(p=>p.alpha*=gain);
  if(c.reverse)pixels.reverse();
  return {pixels,paired,seam:paired?Math.ceil(n/2):null,headCount:pixels.filter(p=>p.head&&p.alpha>0).length,tick:rawTime};
 }
 // Reflect a complete directional pass; effects already bouncing keep their own path.
 function directionPhase(m,n,h,tail,t,bounce){
  const travel=Math.max(1,n-h),cycle=n+Math.max(8,tail);let leg=0;
  if([1,2,37,38].includes(m))leg=travel;
  else if([4,5].includes(m))leg=travel/2;
  else if(m===6)leg=travel/2+10;
  else if(m===7)leg=travel/2+16;
  else if(m===8)leg=n+h;
  else if([9,10,25,49].includes(m))leg=n;
  else if([11,13].includes(m))leg=cycle;
  else if(m===12)leg=cycle/.85;
  else if(m===14)leg=cycle+h;
  else if([19,46].includes(m))leg=n+8;
  else if(m===20)leg=n+10;
  else if(m===22)leg=2*n+24;
  else if(m===23)leg=(n+12)/2;
  else if(m===24)leg=n/2+12;
  else if(m===26)leg=(n+h+10)/2;
  else if(m===27){for(let k=0;k<Math.ceil(n/h);k++)leg+=Math.max(0,n-(k+1)*h)+h+2;leg+=16;}
  else if([41,45].includes(m))leg=n+h+tail;
  else if(m===42)leg=(n+h+tail)/.65;
  else if(m===43)leg=(n+h+4)/1.3;
  else if(m===44)leg=60;
  if(!bounce||leg<=0)return {time:t,dir:1};
  const q=mod(t,2*leg),back=q>leg;
  return {time:Math.min(leg-1e-6,back?2*leg-q:q),dir:back?-1:1};
 }
 // Exact calculateAppStepMs() mapping from the current custom firmware.
 const api={normalize,frame,description:p=>descriptions[normalize(p).mode-1],descriptions,delay:p=>50-Math.floor(((normalize(p).speed-1)*45+49)/99),supported:false};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else scope.HsCustomEngine=api;
})(typeof window!=='undefined'?window:globalThis);
