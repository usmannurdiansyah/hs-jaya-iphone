import UIKit
import WebKit

private final class ScriptMessageProxy: NSObject, WKScriptMessageHandler {
    weak var owner: ViewController?
    init(_ owner: ViewController) { self.owner = owner; super.init() }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        owner?.userContentController(userContentController, didReceive: message)
    }
}

final class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate {
    private var web: WKWebView!
    private let bluetooth = BluetoothTransport()
    private var contentRoot: URL!
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 5/255, green: 5/255, blue: 13/255, alpha: 1)
        let controller = WKUserContentController()
        controller.add(ScriptMessageProxy(self), name: "hsjaya")
        for name in ["protocol", "ios-bridge"] {
            guard let url = Bundle.main.url(forResource: name, withExtension: "js", subdirectory: "Native"),
                  let source = try? String(contentsOf: url, encoding: .utf8) else { fatalError("Missing native adapter: \(name)") }
            controller.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        }
        let config = WKWebViewConfiguration()
        config.userContentController = controller
        config.websiteDataStore = .default()
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.isOpaque = false; web.backgroundColor = view.backgroundColor
        web.scrollView.backgroundColor = view.backgroundColor
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
        ])
        guard let entry = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") else { fatalError("Missing original APK interface") }
        contentRoot = entry.deletingLastPathComponent()
        bluetooth.event = { [weak self] event in self?.emit(event) }
        web.loadFileURL(entry, allowingReadAccessTo: contentRoot)
    }
    private func emit(_ event: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: event, options: [.fragmentsAllowed]),
              let json = String(data: data, encoding: .utf8) else { return }
        web.evaluateJavaScript("window.__hsIOSReceive && window.__hsIOSReceive(\(json));", completionHandler: nil)
    }
    private func reply(_ id: Int, error: String? = nil) {
        var event: [String: Any] = ["type": "reply", "id": id]
        if let error = error { event["error"] = error }; emit(event)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, let url = message.frameInfo.request.url, url.isFileURL,
              url.standardizedFileURL.path.hasPrefix(contentRoot.standardizedFileURL.path + "/"),
              let body = message.body as? [String: Any], let id = body["id"] as? Int,
              let method = body["method"] as? String else { return }
        switch method {
        case "connect": bluetooth.connect(); reply(id)
        case "disconnect": bluetooth.disconnect(); reply(id)
        case "write":
            guard let device = body["device"] as? String, let characteristic = body["characteristic"] as? String,
                  let bytes = body["bytes"] as? [Int], Self.validUUID(characteristic) else { reply(id, error: "Paket tidak valid"); return }
            bluetooth.write(device: device, characteristic: characteristic, bytes: bytes, request: id)
        case "subscribe":
            guard let device = body["device"] as? String, let characteristic = body["characteristic"] as? String,
                  Self.validUUID(characteristic) else { reply(id, error: "Layanan tidak valid"); return }
            bluetooth.subscribe(device: device, characteristic: characteristic, request: id)
        case "ota":
            if let url = URL(string: "https://ledcar-ota.usmannurdiansyah.workers.dev") { UIApplication.shared.open(url) }
            reply(id)
        case "exit":
            // iOS apps must not terminate themselves. Keep the existing menu item.
            reply(id)
            let alert = UIAlertController(title: "HS JAYA", message: "Gunakan gestur Home untuk menutup aplikasi.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default)); present(alert, animated: true)
        default: reply(id, error: "Perintah tidak tersedia")
        }
    }
    private static func validUUID(_ s: String) -> Bool {
        s.range(of: "^(?:[0-9A-Fa-f]{4}|[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12})$", options: .regularExpression) != nil
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL && url.standardizedFileURL.path.hasPrefix(contentRoot.standardizedFileURL.path + "/") { decisionHandler(.allow) }
        else {
            decisionHandler(.cancel)
            if ["https", "http", "mailto"].contains(url.scheme?.lowercased() ?? "") { UIApplication.shared.open(url) }
        }
    }
    deinit { bluetooth.disconnect() }
}
